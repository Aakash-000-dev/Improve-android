import 'dart:convert';
import 'dart:typed_data';

import 'package:sqflite/sqflite.dart';

import '../database/database_helper.dart';

/// Portable offline-first backup for all user data stored in SQLite.
class BackupService {
  BackupService._();
  static final BackupService instance = BackupService._();
  static const int formatVersion = 1;
  static const List<String> _tables = [
    'defaults', 'initialized_days', 'daily_items', 'notes', 'planner', 'app_settings',
  ];

  Future<Uint8List> createBackup() async {
    final db = await DatabaseHelper.instance.database;
    final data = <String, Object?>{};
    await db.transaction((txn) async {
      for (final table in _tables) {
        data[table] = await txn.query(table);
      }
    });
    final document = <String, Object?>{
      'app': 'Improve',
      'backupFormatVersion': formatVersion,
      'createdAt': DateTime.now().toUtc().toIso8601String(),
      'databaseSchemaVersion': await db.getVersion(),
      'tables': data,
    };
    return Uint8List.fromList(utf8.encode(const JsonEncoder.withIndent('  ').convert(document)));
  }

  /// Fully validates the file before replacing data. The transaction rolls back
  /// automatically if any row cannot be restored or the integrity check fails.
  Future<void> restoreBackup(Uint8List bytes) async {
    final dynamic decoded;
    try {
      decoded = jsonDecode(utf8.decode(bytes));
    } on FormatException {
      throw const FormatException('This backup file is not valid JSON.');
    }
    if (decoded is! Map<String, dynamic> ||
        decoded['app'] != 'Improve' ||
        decoded['backupFormatVersion'] != formatVersion ||
        decoded['tables'] is! Map<String, dynamic>) {
      throw const FormatException('This is not a supported Improve backup.');
    }
    final tables = decoded['tables'] as Map<String, dynamic>;
    for (final table in _tables) {
      final rows = tables[table];
      if (rows is! List || rows.any((row) => row is! Map)) {
        throw FormatException('Backup is missing valid "$table" data.');
      }
    }

    final db = await DatabaseHelper.instance.database;
    await db.transaction((txn) async {
      for (final table in ['daily_items', 'initialized_days', 'notes', 'planner', 'app_settings', 'defaults']) {
        await txn.delete(table);
      }
      for (final table in _tables) {
        for (final rawRow in tables[table] as List) {
          await txn.insert(table, Map<String, Object?>.from(rawRow as Map), conflictAlgorithm: ConflictAlgorithm.abort);
        }
      }
      final integrity = await txn.rawQuery('PRAGMA quick_check');
      if (integrity.isEmpty || integrity.first.values.first != 'ok') {
        throw StateError('Restored database failed its integrity check.');
      }
    });
  }
}
