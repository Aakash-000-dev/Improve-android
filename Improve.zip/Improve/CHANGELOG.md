# Changelog

## 1.1.0+2
- Added SQLite persistence for daily routines, checkpoints, notes, Global Planner, defaults and preferences.
- Added per-date initialization so default changes do not rewrite existing day records.
- Added reusable frosted-glass panels and updated light/dark themes.
- Updated settings to manage default objectives and checkpoints independently from the selected day's routine.
- Updated save confirmations and About information.

## 1.2.0
- Added predefined random motivational notifications.
- Added configurable random interval range, active hours and daily cap.
- Added rolling seven-day local notification scheduling and Android restart integration instructions.


## 1.2.2+5
- Added immediate high-priority notifications when a user completes an objective or checkpoint.
- Completion notifications are sent only for newly completed items on the current day and only while Reminders are enabled.
- Unchecking an item and editing historical days do not send completion notifications.
- Notification errors do not interrupt saving task completion.
