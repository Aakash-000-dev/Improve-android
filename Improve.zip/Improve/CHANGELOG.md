## 1.2.6+9
- Fixed device timezone initialization for notification scheduling.
- Normalized Asia/Calcutta to Asia/Kolkata with a safe fallback.

# Changelog

## 1.1.0+2
- Added SQLite persistence for daily routines, checkpoints, notes, Global Planner, defaults and preferences.
- Added per-date initialization so default changes do not rewrite existing day records.
- Added reusable frosted-glass panels and updated light/dark themes.
- Updated settings to manage default objectives and checkpoints independently from the selected day's routine.
- Updated save confirmations and About information.

## 1.2.0
- Added predefined random motivational notifications.
- Added configurable random interval range, active hours and daily cap.
- Added rolling seven-day local notification scheduling and Android restart integration instructions.
