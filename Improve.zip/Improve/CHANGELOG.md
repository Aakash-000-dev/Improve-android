# Changelog

## 1.1.0+2
- Added SQLite persistence for daily routines, checkpoints, notes, Global Planner, defaults and preferences.
- Added per-date initialization so default changes do not rewrite existing day records.
- Added reusable frosted-glass panels and updated light/dark themes.
- Updated settings to manage default objectives and checkpoints independently from the selected day's routine.
- Updated save confirmations and About information.
