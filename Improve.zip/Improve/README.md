# Improve 1.1.0

Improve is an offline-first Flutter routine and planning app. This update adds local SQLite persistence and a restrained glassmorphism visual system.

## What's upgraded

### Local database
- SQLite database file: `improve.db` in the platform's application database directory.
- Default objectives and checkpoints are stored separately from daily records.
- The first time a date is opened, its daily objectives/checkpoints are copied from the current defaults.
- Existing dates are not rewritten when defaults are edited, added, or removed.
- Completion state is stored per date and per item.
- Daily notes are stored by date.
- Global Planner content is stored separately from daily notes.
- Theme and reminder preference are persisted locally.
- Database operations use parameterized sqflite queries and transactions for first-day creation.

### Interface
- Reusable frosted-glass panels with blur, translucent surfaces, subtle borders and shadows.
- Soft gradient page background.
- Updated light and dark palettes.
- System/light/dark appearance selection remains available.
- Text contrast is kept readable; blur is restrained to avoid turning every screen into a fog machine.

## Project setup

This ZIP contains the Flutter project source files. If you already have the generated `android/` folder and GitHub Actions workflow in your working project, keep them. Copy/merge this ZIP's `lib/` and `pubspec.yaml` into that project rather than deleting its platform folders or workflow files.

From the project root:

```powershell
flutter pub get
flutter analyze
```

For an Android device or a cloud APK build, use your existing Android build workflow. The new database dependency is `sqflite` and the path helper is `path`.

## Database behaviour

- Defaults are templates for dates that have not been initialized yet.
- When a date is initialized for the first time, active defaults are copied into `daily_items` and the date is recorded in `initialized_days`.
- Later changes to defaults do not mutate that date's records.
- Adding/editing/deleting a routine from the Routines screen changes only the selected date's daily record.
- Deleting a default removes it from future templates without deleting historical daily items.

## Current limitations

- This build uses `sqflite`, which targets Android/iOS/macOS. The Chrome web preview is not a supported runtime for the SQLite implementation.
- Reminder setting is persisted as a preference, but real scheduled Android notifications are not implemented yet.
- Statistics currently summarize the selected day's objectives. Trend charts and cross-date analytics are not implemented.
- No cloud sync or database export/backup is included. App data is local to the device; uninstalling the app may remove it.
- The source ZIP does not include generated Android platform files or your GitHub Actions workflow. Preserve those from your existing project.

## Suggested verification

1. Add an objective and checkpoint for today, then mark them complete.
2. Save a daily note and Global Planner text.
3. Close and reopen the app; confirm all three persist.
4. Open a different date and confirm it receives the current defaults.
5. Change a default in Settings, then reopen an older date and confirm its saved list is unchanged.
6. Build and install the APK on the same phone before replacing your previous release.
