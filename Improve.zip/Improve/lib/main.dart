import 'package:flutter/material.dart';
import 'app/improve_app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ImproveApp());
}
