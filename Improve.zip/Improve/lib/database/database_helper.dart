import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  DatabaseHelper._();
  static final DatabaseHelper instance = DatabaseHelper._();
  Database? _database;

  static const _dbName = 'improve.db';
  static const _backupName = 'improve_backup.db';

  Future<Database> get database async {
    if (_database != null) return _database!;
    final root = await getDatabasesPath();
    final dbPath = p.join(root, _dbName);

    // Restore from backup if the main database is missing (update / reinstall)
    await _tryRestore(dbPath);

    _database = await openDatabase(
      dbPath,
      version: 1,
      onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: (db, version) async {
        await db.execute('''CREATE TABLE defaults (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          type TEXT NOT NULL CHECK(type IN ('objective','checkpoint')),
          sort_order INTEGER NOT NULL DEFAULT 0,
          active INTEGER NOT NULL DEFAULT 1
        )''');
        await db.execute('''CREATE TABLE initialized_days (
          date_key TEXT PRIMARY KEY,
          created_at TEXT NOT NULL
        )''');
        await db.execute('''CREATE TABLE daily_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          date_key TEXT NOT NULL,
          title TEXT NOT NULL,
          type TEXT NOT NULL CHECK(type IN ('objective','checkpoint')),
          completed INTEGER NOT NULL DEFAULT 0,
          default_id INTEGER,
          created_at TEXT NOT NULL,
          FOREIGN KEY(default_id) REFERENCES defaults(id) ON DELETE SET NULL
        )''');
        await db.execute('CREATE INDEX daily_items_date_idx ON daily_items(date_key)');
        await db.execute('''CREATE TABLE notes (
          date_key TEXT PRIMARY KEY,
          content TEXT NOT NULL DEFAULT '',
          updated_at TEXT NOT NULL
        )''');
        await db.execute('''CREATE TABLE planner (
          id INTEGER PRIMARY KEY CHECK(id = 1),
          content TEXT NOT NULL DEFAULT '',
          updated_at TEXT NOT NULL
        )''');
        await db.execute('''CREATE TABLE app_settings (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL
        )''');
        final now = DateTime.now().toIso8601String();
        await db.insert('planner', {'id': 1, 'content': '', 'updated_at': now});
        const objectives = ['Complete daily routine', 'Study with focus', 'Review today’s progress'];
        const checkpoints = ['Morning routine', 'Study session', 'Evening review'];
        for (var i = 0; i < objectives.length; i++) {
          await db.insert('defaults', {'title': objectives[i], 'type': 'objective', 'sort_order': i});
        }
        for (var i = 0; i < checkpoints.length; i++) {
          await db.insert('defaults', {'title': checkpoints[i], 'type': 'checkpoint', 'sort_order': i});
        }
      },
    );
    return _database!;
  }

  /// Copies the live database to a backup location that survives most updates.
  Future<void> backup() async {
    try {
      final root = await getDatabasesPath();
      final dbPath = p.join(root, _dbName);
      final dbFile = File(dbPath);
      if (!await dbFile.exists()) return;

      final backupDir = await _backupDirectory();
      final backupPath = p.join(backupDir.path, _backupName);
      await dbFile.copy(backupPath);
    } catch (_) {}
  }

  Future<void> _tryRestore(String dbPath) async {
    final main = File(dbPath);
    if (await main.exists()) return;
    try {
      final backupDir = await _backupDirectory();
      final backup = File(p.join(backupDir.path, _backupName));
      if (await backup.exists()) {
        await main.parent.create(recursive: true);
        await backup.copy(dbPath);
      }
    } catch (_) {}
  }

  Future<Directory> _backupDirectory() async {
    final external = await getExternalStorageDirectory();
    if (external != null) return external;
    return getApplicationDocumentsDirectory();
  }

  Future<void> close() async {
    await _database?.close();
    _database = null;
  }
}
