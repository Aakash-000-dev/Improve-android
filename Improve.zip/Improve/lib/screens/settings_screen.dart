import 'package:flutter/material.dart';
import '../state/improve_controller.dart';
import '../widgets/add_item_dialog.dart';
import '../widgets/section_header.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.controller});
  final ImproveController controller;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: controller,
    builder: (context, _) => ListView(
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 28),
      children: [
        const SectionHeader(title: 'Settings', subtitle: 'Make Improve work the way you do.'),
        Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.brightness_6_outlined),
                title: const Text('Appearance'),
                subtitle: Text(_themeLabel(controller.themeMode)),
                trailing: DropdownButton<ThemeMode>(
                  value: controller.themeMode,
                  underline: const SizedBox.shrink(),
                  items: const [
                    DropdownMenuItem(value: ThemeMode.system, child: Text('System')),
                    DropdownMenuItem(value: ThemeMode.light, child: Text('Light')),
                    DropdownMenuItem(value: ThemeMode.dark, child: Text('Dark')),
                  ],
                  onChanged: (mode) {
                    if (mode != null) controller.setThemeMode(mode);
                  },
                ),
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              SwitchListTile(
                secondary: const Icon(Icons.notifications_active_outlined),
                title: const Text('Reminders'),
                subtitle: const Text('Notification scheduling will be connected later.'),
                value: controller.remindersEnabled,
                onChanged: controller.setReminders,
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.flag_outlined),
                title: const Text('Default objectives'),
                subtitle: Text('${controller.objectives.length} sample objectives currently shown'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () async {
                  final value = await showAddItemDialog(context, title: 'Add default objective');
                  if (value != null) controller.addObjective(value);
                },
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              ListTile(
                leading: const Icon(Icons.checklist_outlined),
                title: const Text('Default checkpoints'),
                subtitle: Text('${controller.checkpoints.length} sample checkpoints currently shown'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () async {
                  final value = await showAddItemDialog(context, title: 'Add default checkpoint');
                  if (value != null) controller.addObjective(value, checkpoint: true);
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Text(
          'Prototype note: settings and content currently live in memory and reset when the app closes. SQLite persistence is the next implementation phase.',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant),
        ),
      ],
    ),
  );

  String _themeLabel(ThemeMode mode) {
    switch (mode) {
      case ThemeMode.system: return 'Follow device theme';
      case ThemeMode.light: return 'Light theme';
      case ThemeMode.dark: return 'Dark theme';
    }
  }
}
