import 'package:flutter/material.dart';
import '../widgets/glass_card.dart';
import '../state/improve_controller.dart';
import '../widgets/section_header.dart';

class PlannerScreen extends StatefulWidget {
  const PlannerScreen({super.key, required this.controller});
  final ImproveController controller;

  @override
  State<PlannerScreen> createState() => _PlannerScreenState();
}

class _PlannerScreenState extends State<PlannerScreen> {
  late final TextEditingController textController;

  @override
  void initState() {
    super.initState();
    textController = TextEditingController(text: widget.controller.globalPlan);
  }

  @override
  void dispose() {
    textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(20, 22, 20, 28),
    children: [
      const SectionHeader(title: 'Global Planner', subtitle: 'Plans that stay independent of any date.'),
      GlassCard(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Your plan', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 14),
              TextField(
                controller: textController,
                minLines: 14,
                maxLines: 22,
                maxLength: 10000,
                decoration: const InputDecoration(
                  hintText: 'Goals, project plans, ideas, next steps…',
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () async {
                    await widget.controller.saveGlobalPlan(textController.text);
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Plan saved on this device.')));
                  },
                  icon: const Icon(Icons.save_outlined),
                  label: const Text('Save plan'),
                ),
              ),
            ],
          ),
        ),
      ),
    ],
  );
}
