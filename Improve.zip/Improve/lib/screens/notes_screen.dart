import 'package:flutter/material.dart';
import '../widgets/glass_card.dart';
import '../state/improve_controller.dart';
import '../widgets/section_header.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key, required this.controller});
  final ImproveController controller;

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  late final TextEditingController textController;
  String loadedKey = '';

  @override
  void initState() {
    super.initState();
    loadedKey = widget.controller.selectedDateKey;
    textController = TextEditingController(text: widget.controller.currentNote);
    widget.controller.addListener(_syncDate);
  }

  void _syncDate() {
    final newKey = widget.controller.selectedDateKey;
    if (newKey != loadedKey) {
      loadedKey = newKey;
      textController.text = widget.controller.currentNote;
      setState(() {});
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_syncDate);
    textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(20, 22, 20, 28),
    children: [
      const SectionHeader(title: 'Notes', subtitle: 'Capture thoughts for the selected day.'),
      GlassCard(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Daily note · $loadedKey', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 14),
              TextField(
                controller: textController,
                minLines: 12,
                maxLines: 18,
                maxLength: 5000,
                decoration: const InputDecoration(
                  hintText: 'What mattered today?',
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () async {
                    await widget.controller.saveNote(textController.text);
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Note saved on this device.')));
                  },
                  icon: const Icon(Icons.save_outlined),
                  label: const Text('Save note'),
                ),
              ),
            ],
          ),
        ),
      ),
    ],
  );
}
