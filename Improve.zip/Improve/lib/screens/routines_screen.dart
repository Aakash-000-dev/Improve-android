import 'package:flutter/material.dart';
import '../models/objective.dart';
import '../state/improve_controller.dart';
import '../widgets/add_item_dialog.dart';
import '../widgets/objective_tile.dart';
import '../widgets/section_header.dart';

class RoutinesScreen extends StatelessWidget {
  const RoutinesScreen({super.key, required this.controller});
  final ImproveController controller;

  Future<void> _add(BuildContext context, {bool checkpoint = false}) async {
    final value = await showAddItemDialog(context, title: checkpoint ? 'Add checkpoint' : 'Add objective');
    if (value != null && value.trim().isNotEmpty) {
      controller.addObjective(value, checkpoint: checkpoint);
    }
  }

  Future<void> _edit(BuildContext context, Objective objective) async {
    final value = await showAddItemDialog(context, title: 'Edit objective', initialValue: objective.title);
    if (value != null && value.trim().isNotEmpty) controller.editObjective(objective, value);
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: controller,
    builder: (context, _) => ListView(
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 28),
      children: [
        SectionHeader(
          title: 'Routines',
          subtitle: 'Build consistency one action at a time.',
          trailing: IconButton.filledTonal(
            onPressed: () => _add(context),
            icon: const Icon(Icons.add),
            tooltip: 'Add objective',
          ),
        ),
        _LabelRow(title: 'Objectives', count: controller.objectives.length),
        const SizedBox(height: 10),
        ...controller.objectives.map((item) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: ObjectiveTile(
            objective: item,
            onChanged: (value) => controller.toggleObjective(item, value),
            onEdit: () => _edit(context, item),
            onDelete: () => controller.deleteObjective(item),
          ),
        )),
        const SizedBox(height: 24),
        Row(
          children: [
            const Expanded(child: _LabelRow(title: 'Checkpoints')),
            TextButton.icon(
              onPressed: () => _add(context, checkpoint: true),
              icon: const Icon(Icons.add, size: 18),
              label: const Text('Add'),
            ),
          ],
        ),
        const SizedBox(height: 10),
        ...controller.checkpoints.map((item) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: ObjectiveTile(
            objective: item,
            onChanged: (value) => controller.toggleObjective(item, value),
            onEdit: () => _edit(context, item),
            onDelete: () => controller.deleteObjective(item),
          ),
        )),
      ],
    ),
  );
}

class _LabelRow extends StatelessWidget {
  const _LabelRow({required this.title, this.count});
  final String title;
  final int? count;

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Expanded(child: Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800))),
      if (count != null) Text('$count', style: Theme.of(context).textTheme.labelLarge),
    ],
  );
}
