import 'package:flutter/material.dart';
import '../state/improve_controller.dart';
import '../widgets/section_header.dart';

class StatisticsScreen extends StatelessWidget {
  const StatisticsScreen({super.key, required this.controller});
  final ImproveController controller;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: controller,
    builder: (context, _) => ListView(
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 28),
      children: [
        const SectionHeader(title: 'Statistics', subtitle: 'A simple snapshot of your current progress.'),
        Row(
          children: [
            Expanded(child: _StatCard(title: 'Completion', value: '${(controller.progress * 100).round()}%', icon: Icons.donut_large_rounded)),
            const SizedBox(width: 12),
            Expanded(child: _StatCard(title: 'Completed', value: '${controller.completedCount}/${controller.totalCount}', icon: Icons.task_alt_rounded)),
          ],
        ),
        const SizedBox(height: 14),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Today', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 14),
                LinearProgressIndicator(value: controller.progress, minHeight: 10, borderRadius: BorderRadius.circular(99)),
                const SizedBox(height: 12),
                Text('${controller.completedCount} objectives completed out of ${controller.totalCount}. Historical charts will be added after persistent storage is implemented.'),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.title, required this.value, required this.icon});
  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: Theme.of(context).colorScheme.primary, size: 25),
          const SizedBox(height: 18),
          Text(value, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(title, style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    ),
  );
}
