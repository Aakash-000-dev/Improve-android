import 'package:flutter/material.dart';
import '../widgets/section_header.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(20, 22, 20, 28),
    children: [
      const SectionHeader(title: 'About Improve', subtitle: 'A simple space to make progress visible.'),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Icon(Icons.bolt_rounded, size: 42, color: Theme.of(context).colorScheme.onPrimaryContainer),
              ),
              const SizedBox(height: 16),
              Text('Improve', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              const Text('Version 1.0.0 · Development prototype'),
              const SizedBox(height: 18),
              const Text(
                'Improve is designed for daily routines, checkpoints, notes, planning and progress tracking. This starter version uses sample data and has not yet connected SQLite storage or Android notifications.',
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    ],
  );
}
