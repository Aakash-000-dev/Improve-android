import 'package:flutter/material.dart';
import '../models/objective.dart';
import '../widgets/add_item_dialog.dart';
import '../widgets/glass_card.dart';
import '../state/improve_controller.dart';
import '../widgets/objective_tile.dart';
import '../widgets/section_header.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.controller});
  final ImproveController controller;

  Future<void> _add(BuildContext context, {bool checkpoint = false}) async {
    final value = await showAddItemDialog(
      context,
      title: checkpoint ? 'Add checkpoint' : 'Add objective',
    );
    if (value != null && value.trim().isNotEmpty) {
      controller.addObjective(value, checkpoint: checkpoint);
    }
  }

  Future<void> _edit(BuildContext context, Objective item) async {
    final value = await showAddItemDialog(
      context,
      title: item.isCheckpoint ? 'Edit checkpoint' : 'Edit objective',
      initialValue: item.title,
    );
    if (value != null && value.trim().isNotEmpty) {
      controller.editObjective(item, value);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) => ListView(
        padding: const EdgeInsets.fromLTRB(20, 22, 20, 28),
        children: [
          SectionHeader(
            title: 'Improve',
            subtitle: _greeting(),
            trailing: CircleAvatar(
              radius: 23,
              backgroundColor: theme.brightness == Brightness.dark
                  ? const Color(0xFF1F1C4A)
                  : theme.colorScheme.primaryContainer,
              child: Icon(
                Icons.bolt_rounded,
                color: theme.brightness == Brightness.dark
                    ? const Color(0xFFC4B5FD)
                    : theme.colorScheme.onPrimaryContainer,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: theme.brightness == Brightness.dark
                    ? const [Color(0xFF1A1740), Color(0xFF2A1F5E), Color(0xFF3D2A7A)]
                    : [theme.colorScheme.primary, theme.colorScheme.tertiary],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(22),
              border: theme.brightness == Brightness.dark
                  ? Border.all(color: const Color(0xFF3D3580).withValues(alpha: .5))
                  : null,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'TODAY’S PROGRESS',
                  style: theme.textTheme.labelLarge?.copyWith(
                    color: Colors.white.withValues(alpha: .85),
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  '${(controller.progress * 100).round()}%',
                  style: theme.textTheme.displaySmall?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  '${controller.completedCount} of ${controller.totalCount} objectives completed',
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(height: 18),
                ClipRRect(
                  borderRadius: BorderRadius.circular(99),
                  child: LinearProgressIndicator(
                    value: controller.progress,
                    minHeight: 8,
                    backgroundColor: Colors.white.withValues(alpha: .18),
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 26),
          _sectionHeading(context, 'Today’s objectives', onAdd: () => _add(context)),
          const SizedBox(height: 10),
          if (controller.objectives.isEmpty)
            const _EmptyState(message: 'No objectives yet. Add your first objective here.')
          else
            ...controller.objectives.map((item) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: ObjectiveTile(
                objective: item,
                onChanged: (value) => controller.toggleObjective(item, value),
                onEdit: () => _edit(context, item),
                onDelete: () => controller.deleteObjective(item),
              ),
            )),
          const SizedBox(height: 16),
          _sectionHeading(context, 'Checkpoints', onAdd: () => _add(context, checkpoint: true)),
          const SizedBox(height: 10),
          if (controller.checkpoints.isEmpty)
            const _EmptyState(message: 'No checkpoints yet. Add smaller actions to track your day.')
          else
            ...controller.checkpoints.map((item) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: ObjectiveTile(
                objective: item,
                onChanged: (value) => controller.toggleObjective(item, value),
                onEdit: () => _edit(context, item),
                onDelete: () => controller.deleteObjective(item),
              ),
            )),
          const SizedBox(height: 16),
          Text('A small step still counts.', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Text('Focus on making today a little better than yesterday.', style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
        ],
      ),
    );
  }

  Widget _sectionHeading(BuildContext context, String title, {required VoidCallback onAdd}) => Row(
    children: [
      Expanded(child: Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800))),
      IconButton.filledTonal(onPressed: onAdd, icon: const Icon(Icons.add), tooltip: 'Add'),
    ],
  );

  String _greeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning. Start with one useful thing.';
    if (hour < 17) return 'Good afternoon. Keep your focus on what matters.';
    return 'Good evening. Make time to review your day.';
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.message});
  final String message;
  @override
  Widget build(BuildContext context) => GlassCard(
    child: Padding(padding: const EdgeInsets.all(20), child: Text(message)),
  );
}
