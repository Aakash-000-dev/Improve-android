import 'package:flutter/material.dart';
import '../models/objective.dart';

class ImproveController extends ChangeNotifier {
  ThemeMode themeMode = ThemeMode.system;
  DateTime selectedDate = DateTime.now();
  int _nextId = 4;

  final List<Objective> objectives = [
    Objective(id: 1, title: 'Complete daily routine'),
    Objective(id: 2, title: 'Study with focus'),
    Objective(id: 3, title: 'Review today’s progress'),
  ];

  final List<Objective> checkpoints = [
    Objective(id: 101, title: 'Morning routine', isCheckpoint: true),
    Objective(id: 102, title: 'Study session', isCheckpoint: true),
    Objective(id: 103, title: 'Evening review', isCheckpoint: true),
  ];

  final Map<String, String> notes = {};
  String globalPlan = 'Write your long-term plans here. They stay separate from daily notes.';
  bool remindersEnabled = false;

  int get completedCount => objectives.where((item) => item.done).length;
  int get totalCount => objectives.length;
  double get progress => totalCount == 0 ? 0 : completedCount / totalCount;

  String get selectedDateKey =>
      '${selectedDate.year.toString().padLeft(4, '0')}-'
      '${selectedDate.month.toString().padLeft(2, '0')}-'
      '${selectedDate.day.toString().padLeft(2, '0')}';

  void toggleObjective(Objective objective, bool value) {
    objective.done = value;
    notifyListeners();
  }

  void addObjective(String title, {bool checkpoint = false}) {
    final cleaned = title.trim();
    if (cleaned.isEmpty) return;
    final target = checkpoint ? checkpoints : objectives;
    target.add(Objective(
      id: _nextId++,
      title: cleaned,
      isCheckpoint: checkpoint,
    ));
    notifyListeners();
  }

  void editObjective(Objective objective, String title) {
    final cleaned = title.trim();
    if (cleaned.isEmpty) return;
    objective.title = cleaned;
    notifyListeners();
  }

  void deleteObjective(Objective objective) {
    objectives.removeWhere((item) => item.id == objective.id);
    checkpoints.removeWhere((item) => item.id == objective.id);
    notifyListeners();
  }

  void selectDate(DateTime date) {
    selectedDate = DateTime(date.year, date.month, date.day);
    notifyListeners();
  }

  void saveNote(String value) {
    notes[selectedDateKey] = value;
    notifyListeners();
  }

  String get currentNote => notes[selectedDateKey] ?? '';

  void saveGlobalPlan(String value) {
    globalPlan = value;
    notifyListeners();
  }

  void setThemeMode(ThemeMode mode) {
    themeMode = mode;
    notifyListeners();
  }

  void setReminders(bool enabled) {
    remindersEnabled = enabled;
    notifyListeners();
  }
}
