import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../database/database_helper.dart';
import '../models/objective.dart';

class ImproveController extends ChangeNotifier {
  final DatabaseHelper _helper = DatabaseHelper.instance;
  ThemeMode themeMode = ThemeMode.system;
  DateTime selectedDate = DateTime.now();
  List<Objective> objectives = [];
  List<Objective> checkpoints = [];
  List<Map<String, Object?>> defaultObjectives = [];
  List<Map<String, Object?>> defaultCheckpoints = [];
  String globalPlan = '';
  String currentNote = '';
  bool remindersEnabled = false;
  bool isReady = false;
  String? loadError;

  int get completedCount => objectives.where((item) => item.done).length;
  int get totalCount => objectives.length;
  double get progress => totalCount == 0 ? 0 : completedCount / totalCount;
  int get checkpointCompletedCount => checkpoints.where((item) => item.done).length;
  String get selectedDateKey => _dateKey(selectedDate);

  static String _dateKey(DateTime date) =>
      '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

  Future<void> initialize() async {
    try {
      final db = await _helper.database;
      final settings = await db.query('app_settings');
      for (final row in settings) {
        final key = row['key'];
        final value = row['value'];
        if (key == 'theme') {
          themeMode = switch (value) {
            'light' => ThemeMode.light,
            'dark' => ThemeMode.dark,
            _ => ThemeMode.system,
          };
        } else if (key == 'reminders') {
          remindersEnabled = value == '1';
        }
      }
      final plan = await db.query('planner', where: 'id = 1', limit: 1);
      globalPlan = plan.isEmpty ? '' : plan.first['content'] as String;
      await _loadDefaults();
      await _loadDay();
      isReady = true;
    } catch (error) {
      loadError = error.toString();
    }
    notifyListeners();
  }

  Future<void> _loadDefaults() async {
    final db = await _helper.database;
    defaultObjectives = await db.query('defaults', where: 'type = ? AND active = 1', whereArgs: ['objective'], orderBy: 'sort_order, id');
    defaultCheckpoints = await db.query('defaults', where: 'type = ? AND active = 1', whereArgs: ['checkpoint'], orderBy: 'sort_order, id');
  }

  Future<void> _loadDay() async {
    final db = await _helper.database;
    final key = selectedDateKey;
    await db.transaction((txn) async {
      final initialized = await txn.query('initialized_days', where: 'date_key = ?', whereArgs: [key], limit: 1);
      if (initialized.isEmpty) {
        final defaults = await txn.query('defaults', where: 'active = 1', orderBy: 'sort_order, id');
        for (final item in defaults) {
          await txn.insert('daily_items', {
            'date_key': key,
            'title': item['title'],
            'type': item['type'],
            'completed': 0,
            'default_id': item['id'],
            'created_at': DateTime.now().toIso8601String(),
          });
        }
        await txn.insert('initialized_days', {'date_key': key, 'created_at': DateTime.now().toIso8601String()});
      }
    });
    final rows = await db.query('daily_items', where: 'date_key = ?', whereArgs: [key], orderBy: 'id');
    objectives = rows.where((r) => r['type'] == 'objective').map(Objective.fromMap).toList();
    checkpoints = rows.where((r) => r['type'] == 'checkpoint').map(Objective.fromMap).toList();
    final note = await db.query('notes', where: 'date_key = ?', whereArgs: [key], limit: 1);
    currentNote = note.isEmpty ? '' : note.first['content'] as String;
  }

  Future<void> selectDate(DateTime date) async {
    selectedDate = DateTime(date.year, date.month, date.day);
    await _loadDay();
    notifyListeners();
  }

  Future<void> toggleObjective(Objective item, bool value) async {
    item.done = value;
    final db = await _helper.database;
    await db.update('daily_items', {'completed': value ? 1 : 0}, where: 'id = ? AND date_key = ?', whereArgs: [item.id, selectedDateKey]);
    notifyListeners();
  }

  Future<void> addObjective(String title, {bool checkpoint = false}) async {
    final cleaned = title.trim();
    if (cleaned.isEmpty) return;
    final db = await _helper.database;
    final id = await db.insert('daily_items', {
      'date_key': selectedDateKey,
      'title': cleaned,
      'type': checkpoint ? 'checkpoint' : 'objective',
      'completed': 0,
      'created_at': DateTime.now().toIso8601String(),
    });
    (checkpoint ? checkpoints : objectives).add(Objective(id: id, title: cleaned, isCheckpoint: checkpoint));
    notifyListeners();
  }

  Future<void> editObjective(Objective item, String title) async {
    final cleaned = title.trim();
    if (cleaned.isEmpty) return;
    item.title = cleaned;
    final db = await _helper.database;
    await db.update('daily_items', {'title': cleaned}, where: 'id = ?', whereArgs: [item.id]);
    notifyListeners();
  }

  Future<void> deleteObjective(Objective item) async {
    final db = await _helper.database;
    await db.delete('daily_items', where: 'id = ?', whereArgs: [item.id]);
    objectives.removeWhere((x) => x.id == item.id);
    checkpoints.removeWhere((x) => x.id == item.id);
    notifyListeners();
  }

  Future<void> saveNote(String value) async {
    currentNote = value;
    final db = await _helper.database;
    await db.insert('notes', {'date_key': selectedDateKey, 'content': value, 'updated_at': DateTime.now().toIso8601String()}, conflictAlgorithm: ConflictAlgorithm.replace);
    notifyListeners();
  }

  Future<void> saveGlobalPlan(String value) async {
    globalPlan = value;
    final db = await _helper.database;
    await db.update('planner', {'content': value, 'updated_at': DateTime.now().toIso8601String()}, where: 'id = 1');
    notifyListeners();
  }

  Future<void> addDefault(String title, {bool checkpoint = false}) async {
    final cleaned = title.trim();
    if (cleaned.isEmpty) return;
    final db = await _helper.database;
    await db.insert('defaults', {'title': cleaned, 'type': checkpoint ? 'checkpoint' : 'objective', 'sort_order': DateTime.now().millisecondsSinceEpoch});
    await _loadDefaults();
    notifyListeners();
  }

  Future<void> editDefault(int id, String title) async {
    if (title.trim().isEmpty) return;
    final db = await _helper.database;
    await db.update('defaults', {'title': title.trim()}, where: 'id = ?', whereArgs: [id]);
    await _loadDefaults();
    notifyListeners();
  }

  Future<void> deleteDefault(int id) async {
    final db = await _helper.database;
    await db.update('defaults', {'active': 0}, where: 'id = ?', whereArgs: [id]);
    await _loadDefaults();
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    themeMode = mode;
    final value = mode == ThemeMode.light ? 'light' : mode == ThemeMode.dark ? 'dark' : 'system';
    final db = await _helper.database;
    await db.insert('app_settings', {'key': 'theme', 'value': value}, conflictAlgorithm: ConflictAlgorithm.replace);
    notifyListeners();
  }

  Future<void> setReminders(bool enabled) async {
    remindersEnabled = enabled;
    final db = await _helper.database;
    await db.insert('app_settings', {'key': 'reminders', 'value': enabled ? '1' : '0'}, conflictAlgorithm: ConflictAlgorithm.replace);
    notifyListeners();
  }
}
