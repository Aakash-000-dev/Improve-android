import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../database/database_helper.dart';
import '../models/objective.dart';
import '../notifications/random_notification_service.dart';

class ImproveController extends ChangeNotifier {
  final DatabaseHelper _helper = DatabaseHelper.instance;
  ThemeMode themeMode = ThemeMode.system;
  DateTime selectedDate = DateTime.now();
  List<Objective> objectives = [];
  List<Objective> checkpoints = [];
  List<Map<String, Object?>> defaultObjectives = [];
  List<Map<String, Object?>> defaultCheckpoints = [];
  String globalPlan = '';
  String currentNote = '';
  bool remindersEnabled = false;
  int notificationMinMinutes = 60;
  int notificationMaxMinutes = 180;
  int notificationStartHour = 8;
  int notificationEndHour = 21;
  int notificationDailyLimit = 5;
  bool isReady = false;
  String? loadError;
  String? notificationSetupError;

  int get completedCount => objectives.where((item) => item.done).length;
  int get totalCount => objectives.length;
  double get progress => totalCount == 0 ? 0 : completedCount / totalCount;
  int get checkpointCompletedCount => checkpoints.where((item) => item.done).length;
  String get selectedDateKey => _dateKey(selectedDate);

  static String _dateKey(DateTime date) =>
      '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

  Future<void> initialize() async {
    try {
      final db = await _helper.database;
      final settings = await db.query('app_settings');
      for (final row in settings) {
        final key = row['key'];
        final value = row['value'];
        if (key == 'theme') {
          themeMode = switch (value) {
            'light' => ThemeMode.light,
            'dark' => ThemeMode.dark,
            _ => ThemeMode.system,
          };
        } else if (key == 'reminders') {
          remindersEnabled = value == '1';
        } else if (key == 'notification_min_minutes') {
          notificationMinMinutes = int.tryParse(value.toString()) ?? 60;
        } else if (key == 'notification_max_minutes') {
          notificationMaxMinutes = int.tryParse(value.toString()) ?? 180;
        } else if (key == 'notification_start_hour') {
          notificationStartHour = int.tryParse(value.toString()) ?? 8;
        } else if (key == 'notification_end_hour') {
          notificationEndHour = int.tryParse(value.toString()) ?? 21;
        } else if (key == 'notification_daily_limit') {
          notificationDailyLimit = int.tryParse(value.toString()) ?? 5;
        }
      }
      final plan = await db.query('planner', where: 'id = 1', limit: 1);
      globalPlan = plan.isEmpty ? '' : plan.first['content'] as String;
      await _loadDefaults();
      await _loadDay();
      await _refreshRandomNotifications();
      isReady = true;
    } catch (error) {
      loadError = error.toString();
    }
    notifyListeners();
  }

  Future<void> _loadDefaults() async {
    final db = await _helper.database;
    defaultObjectives = await db.query('defaults', where: 'type = ? AND active = 1', whereArgs: ['objective'], orderBy: 'sort_order, id');
    defaultCheckpoints = await db.query('defaults', where: 'type = ? AND active = 1', whereArgs: ['checkpoint'], orderBy: 'sort_order, id');
  }

  Future<void> _loadDay() async {
    final db = await _helper.database;
    final key = selectedDateKey;
    await db.transaction((txn) async {
      final initialized = await txn.query('initialized_days', where: 'date_key = ?', whereArgs: [key], limit: 1);
      if (initialized.isEmpty) {
        final defaults = await txn.query('defaults', where: 'active = 1', orderBy: 'sort_order, id');
        for (final item in defaults) {
          await txn.insert('daily_items', {
            'date_key': key,
            'title': item['title'],
            'type': item['type'],
            'completed': 0,
            'default_id': item['id'],
            'created_at': DateTime.now().toIso8601String(),
          });
        }
        await txn.insert('initialized_days', {'date_key': key, 'created_at': DateTime.now().toIso8601String()});
      }
    });
    final rows = await db.query('daily_items', where: 'date_key = ?', whereArgs: [key], orderBy: 'id');
    objectives = rows.where((r) => r['type'] == 'objective').map(Objective.fromMap).toList();
    checkpoints = rows.where((r) => r['type'] == 'checkpoint').map(Objective.fromMap).toList();
    final note = await db.query('notes', where: 'date_key = ?', whereArgs: [key], limit: 1);
    currentNote = note.isEmpty ? '' : note.first['content'] as String;
  }

  Future<void> selectDate(DateTime date) async {
    selectedDate = DateTime(date.year, date.month, date.day);
    await _loadDay();
    notifyListeners();
  }

  Future<void> toggleObjective(Objective item, bool value) async {
    final wasDone = item.done;
    item.done = value;
    final db = await _helper.database;
    await db.update(
      'daily_items',
      {'completed': value ? 1 : 0},
      where: 'id = ? AND date_key = ?',
      whereArgs: [item.id, selectedDateKey],
    );

    // Only notify for a newly completed item on today. Editing historical
    // records should not create surprise notifications.
    final now = DateTime.now();
    final isToday = selectedDate.year == now.year &&
        selectedDate.month == now.month &&
        selectedDate.day == now.day;
    if (value && !wasDone && isToday && remindersEnabled) {
      try {
        await RandomNotificationService.instance.showTaskCompleted(
          taskTitle: item.title,
          isCheckpoint: item.isCheckpoint,
        );
      } catch (error) {
        // Notification failures must never prevent task completion from saving.
        notificationSetupError = error.toString();
      }
    }
    notifyListeners();
  }

  Future<void> addObjective(String title, {bool checkpoint = false}) async {
    final cleaned = title.trim();
    if (cleaned.isEmpty) return;
    final db = await _helper.database;
    final id = await db.insert('daily_items', {
      'date_key': selectedDateKey,
      'title': cleaned,
      'type': checkpoint ? 'checkpoint' : 'objective',
      'completed': 0,
      'created_at': DateTime.now().toIso8601String(),
    });
    (checkpoint ? checkpoints : objectives).add(Objective(id: id, title: cleaned, isCheckpoint: checkpoint));
    notifyListeners();
  }

  Future<void> editObjective(Objective item, String title) async {
    final cleaned = title.trim();
    if (cleaned.isEmpty) return;
    item.title = cleaned;
    final db = await _helper.database;
    await db.update('daily_items', {'title': cleaned}, where: 'id = ?', whereArgs: [item.id]);
    notifyListeners();
  }

  Future<void> deleteObjective(Objective item) async {
    final db = await _helper.database;
    await db.delete('daily_items', where: 'id = ?', whereArgs: [item.id]);
    objectives.removeWhere((x) => x.id == item.id);
    checkpoints.removeWhere((x) => x.id == item.id);
    notifyListeners();
  }

  Future<void> saveNote(String value) async {
    currentNote = value;
    final db = await _helper.database;
    await db.insert('notes', {'date_key': selectedDateKey, 'content': value, 'updated_at': DateTime.now().toIso8601String()}, conflictAlgorithm: ConflictAlgorithm.replace);
    notifyListeners();
  }

  Future<void> saveGlobalPlan(String value) async {
    globalPlan = value;
    final db = await _helper.database;
    await db.update('planner', {'content': value, 'updated_at': DateTime.now().toIso8601String()}, where: 'id = 1');
    notifyListeners();
  }

  Future<void> addDefault(String title, {bool checkpoint = false}) async {
    final cleaned = title.trim();
    if (cleaned.isEmpty) return;
    final db = await _helper.database;
    await db.insert('defaults', {'title': cleaned, 'type': checkpoint ? 'checkpoint' : 'objective', 'sort_order': DateTime.now().millisecondsSinceEpoch});
    await _loadDefaults();
    notifyListeners();
  }

  Future<void> editDefault(int id, String title) async {
    if (title.trim().isEmpty) return;
    final db = await _helper.database;
    await db.update('defaults', {'title': title.trim()}, where: 'id = ?', whereArgs: [id]);
    await _loadDefaults();
    notifyListeners();
  }

  Future<void> deleteDefault(int id) async {
    final db = await _helper.database;
    await db.update('defaults', {'active': 0}, where: 'id = ?', whereArgs: [id]);
    await _loadDefaults();
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    themeMode = mode;
    final value = mode == ThemeMode.light ? 'light' : mode == ThemeMode.dark ? 'dark' : 'system';
    final db = await _helper.database;
    await db.insert('app_settings', {'key': 'theme', 'value': value}, conflictAlgorithm: ConflictAlgorithm.replace);
    notifyListeners();
  }

  Future<void> setReminders(bool enabled) async {
    if (enabled) {
      final granted = await RandomNotificationService.instance.requestPermission();
      if (!granted) {
        remindersEnabled = false;
        notifyListeners();
        return;
      }
    }
    remindersEnabled = enabled;
    final db = await _helper.database;
    await db.insert('app_settings', {'key': 'reminders', 'value': enabled ? '1' : '0'}, conflictAlgorithm: ConflictAlgorithm.replace);
    await _refreshRandomNotifications();
    notifyListeners();
  }

  Future<void> setRandomNotificationConfig({
    int? minMinutes,
    int? maxMinutes,
    int? startHour,
    int? endHour,
    int? dailyLimit,
  }) async {
    if (minMinutes != null) notificationMinMinutes = minMinutes;
    if (maxMinutes != null) notificationMaxMinutes = maxMinutes;
    if (startHour != null) notificationStartHour = startHour;
    if (endHour != null) notificationEndHour = endHour;
    if (dailyLimit != null) notificationDailyLimit = dailyLimit;

    final db = await _helper.database;
    final values = <String, int>{
      'notification_min_minutes': notificationMinMinutes,
      'notification_max_minutes': notificationMaxMinutes,
      'notification_start_hour': notificationStartHour,
      'notification_end_hour': notificationEndHour,
      'notification_daily_limit': notificationDailyLimit,
    };
    for (final entry in values.entries) {
      await db.insert('app_settings', {'key': entry.key, 'value': entry.value.toString()}, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await _refreshRandomNotifications();
    notifyListeners();
  }

  Future<void> _refreshRandomNotifications() async {
    try {
      await RandomNotificationService.instance.scheduleSevenDays(
        enabled: remindersEnabled,
        minIntervalMinutes: notificationMinMinutes,
        maxIntervalMinutes: notificationMaxMinutes,
        startHour: notificationStartHour,
        endHour: notificationEndHour,
        dailyLimit: notificationDailyLimit,
      );
      notificationSetupError = null;
    } catch (error) {
      // A notification setup problem must not prevent the core offline app opening.
      notificationSetupError = error.toString();
    }
  }
}
