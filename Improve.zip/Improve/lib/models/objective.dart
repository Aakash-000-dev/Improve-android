class Objective {
  Objective({
    required this.id,
    required this.title,
    this.done = false,
    this.isCheckpoint = false,
  });

  final int id;
  String title;
  bool done;
  final bool isCheckpoint;
}
