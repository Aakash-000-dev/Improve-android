class Objective {
  Objective({
    required this.id,
    required this.title,
    this.done = false,
    this.isCheckpoint = false,
  });

  final int id;
  String title;
  bool done;
  final bool isCheckpoint;

  factory Objective.fromMap(Map<String, Object?> map) => Objective(
    id: map['id'] as int,
    title: map['title'] as String,
    done: (map['completed'] as int? ?? 0) == 1,
    isCheckpoint: map['type'] == 'checkpoint',
  );
}
