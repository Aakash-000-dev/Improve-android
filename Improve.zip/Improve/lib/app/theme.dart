import 'package:flutter/material.dart';

const Color brand = Color(0xFF7B74FF);

ThemeData buildLightTheme() {
  final scheme = ColorScheme.fromSeed(seedColor: brand, brightness: Brightness.light);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: const Color(0xFFF1F2FA),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
    ),
    cardTheme: CardThemeData(
      color: Colors.white.withValues(alpha: .68),
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
        side: BorderSide(color: Colors.white.withValues(alpha: .8)),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white.withValues(alpha: .78),
      elevation: 0,
      indicatorColor: scheme.primaryContainer.withValues(alpha: .8),
      labelTextStyle: WidgetStateProperty.all(
        const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFFEAEBF4).withValues(alpha: .72),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: brand.withValues(alpha: .5)),
      ),
    ),
    dividerTheme: DividerThemeData(color: Colors.black.withValues(alpha: .06)),
  );
}

ThemeData buildDarkTheme() {
  // True OLED palette: pure black surfaces, high-contrast text, restrained accent
  const bg = Color(0xFF000000);
  const surface = Color(0xFF0A0A0A);
  const surfaceHigh = Color(0xFF141414);
  const border = Color(0xFF2A2A2A);
  const onSurface = Color(0xFFF2F2F2);
  const onSurfaceVariant = Color(0xFFB0B0B0);

  final scheme = ColorScheme(
    brightness: Brightness.dark,
    primary: brand,
    onPrimary: Colors.white,
    primaryContainer: const Color(0xFF2A2666),
    onPrimaryContainer: const Color(0xFFE0DEFF),
    secondary: const Color(0xFF9B95FF),
    onSecondary: Colors.black,
    secondaryContainer: const Color(0xFF1F1C4A),
    onSecondaryContainer: const Color(0xFFD8D5FF),
    tertiary: const Color(0xFFC4B5FD),
    onTertiary: Colors.black,
    tertiaryContainer: const Color(0xFF2E1F5E),
    onTertiaryContainer: const Color(0xFFEDE7FF),
    error: const Color(0xFFFF6B6B),
    onError: Colors.black,
    errorContainer: const Color(0xFF4A1515),
    onErrorContainer: const Color(0xFFFFDAD6),
    surface: surface,
    onSurface: onSurface,
    onSurfaceVariant: onSurfaceVariant,
    outline: border,
    outlineVariant: const Color(0xFF1F1F1F),
    shadow: Colors.black,
    scrim: Colors.black,
    inverseSurface: const Color(0xFFE8E8E8),
    onInverseSurface: Colors.black,
    inversePrimary: const Color(0xFF5A52D4),
    surfaceTint: brand,
  );

  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: bg,
    canvasColor: bg,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      foregroundColor: onSurface,
    ),
    cardTheme: CardThemeData(
      color: surfaceHigh,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: border, width: 1),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: bg,
      elevation: 0,
      height: 68,
      indicatorColor: brand.withValues(alpha: .22),
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return TextStyle(
          fontSize: 11,
          fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
          color: selected ? brand : onSurfaceVariant,
        );
      }),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return IconThemeData(
          color: selected ? brand : onSurfaceVariant,
          size: 24,
        );
      }),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surfaceHigh,
      hintStyle: const TextStyle(color: onSurfaceVariant),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: brand.withValues(alpha: .7), width: 1.5),
      ),
    ),
    dividerTheme: const DividerThemeData(color: border, thickness: 1),
    dialogTheme: DialogThemeData(
      backgroundColor: surfaceHigh,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: border),
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: surfaceHigh,
      contentTextStyle: const TextStyle(color: onSurface),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: border),
      ),
      behavior: SnackBarBehavior.floating,
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: brand,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: brand),
    ),
    iconButtonTheme: IconButtonThemeData(
      style: IconButton.styleFrom(foregroundColor: onSurfaceVariant),
    ),
    checkboxTheme: CheckboxThemeData(
      fillColor: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) return brand;
        return Colors.transparent;
      }),
      checkColor: WidgetStateProperty.all(Colors.white),
      side: const BorderSide(color: border, width: 1.5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(
      color: brand,
      linearTrackColor: surfaceHigh,
    ),
  );
}
