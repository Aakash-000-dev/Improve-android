import 'package:flutter/material.dart';

const Color brand = Color(0xFF625BDA);

ThemeData buildLightTheme() {
  final scheme = ColorScheme.fromSeed(seedColor: brand, brightness: Brightness.light);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: const Color(0xFFF1F2FA),
    appBarTheme: const AppBarTheme(backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent, elevation: 0),
    cardTheme: CardThemeData(color: Colors.white.withValues(alpha: .68), elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: Colors.white.withValues(alpha: .8)))),
    navigationBarTheme: NavigationBarThemeData(backgroundColor: Colors.white.withValues(alpha: .78), elevation: 0, indicatorColor: scheme.primaryContainer.withValues(alpha: .8), labelTextStyle: WidgetStateProperty.all(const TextStyle(fontSize: 11, fontWeight: FontWeight.w600))),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xFFEAEBF4).withValues(alpha: .72), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: brand.withValues(alpha: .5)))),
    dividerTheme: DividerThemeData(color: Colors.black.withValues(alpha: .06)),
  );
}

ThemeData buildDarkTheme() {
  final scheme = ColorScheme.fromSeed(seedColor: const Color(0xFFAAA5FF), brightness: Brightness.dark);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: const Color(0xFF11131D),
    appBarTheme: const AppBarTheme(backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent, elevation: 0),
    cardTheme: CardThemeData(color: const Color(0xFF242633).withValues(alpha: .58), elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: Colors.white.withValues(alpha: .12)))),
    navigationBarTheme: NavigationBarThemeData(backgroundColor: const Color(0xFF202230).withValues(alpha: .88), elevation: 0, indicatorColor: scheme.primaryContainer.withValues(alpha: .25)),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xFF292C3B), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)),
    dividerTheme: DividerThemeData(color: Colors.white.withValues(alpha: .08)),
  );
}
