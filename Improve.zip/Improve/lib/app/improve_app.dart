import 'package:flutter/material.dart';
import '../state/improve_controller.dart';
import '../widgets/app_shell.dart';
import 'theme.dart';

class ImproveApp extends StatefulWidget {
  const ImproveApp({super.key});

  @override
  State<ImproveApp> createState() => _ImproveAppState();
}

class _ImproveAppState extends State<ImproveApp> {
  late final ImproveController controller;

  @override
  void initState() {
    super.initState();
    controller = ImproveController();
    controller.addListener(_refresh);
  }

  void _refresh() => setState(() {});

  @override
  void dispose() {
    controller.removeListener(_refresh);
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Improve',
      debugShowCheckedModeBanner: false,
      theme: buildLightTheme(),
      darkTheme: buildDarkTheme(),
      themeMode: controller.themeMode,
      home: AppShell(controller: controller),
    );
  }
}
