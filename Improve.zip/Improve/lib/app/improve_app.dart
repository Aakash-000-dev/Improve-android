import 'package:flutter/material.dart';
import '../state/improve_controller.dart';
import '../widgets/app_shell.dart';
import 'theme.dart';

class ImproveApp extends StatefulWidget {
  const ImproveApp({super.key});
  @override
  State<ImproveApp> createState() => _ImproveAppState();
}

class _ImproveAppState extends State<ImproveApp> {
  late final ImproveController controller;
  @override
  void initState() {
    super.initState();
    controller = ImproveController()..addListener(_refresh);
    controller.initialize();
  }
  void _refresh() { if (mounted) setState(() {}); }
  @override
  void dispose() { controller.removeListener(_refresh); controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Improve',
    debugShowCheckedModeBanner: false,
    theme: buildLightTheme(),
    darkTheme: buildDarkTheme(),
    themeMode: controller.themeMode,
    home: controller.isReady
        ? AppShell(controller: controller)
        : Scaffold(
            backgroundColor: controller.themeMode == ThemeMode.dark
                ? const Color(0xFF000000)
                : null,
            body: Center(
              child: controller.loadError == null
                  ? const Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CircularProgressIndicator(),
                        SizedBox(height: 16),
                        Text('Preparing your space…'),
                      ],
                    )
                  : Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(
                        'Could not open Improve storage.\n${controller.loadError}',
                        textAlign: TextAlign.center,
                      ),
                    ),
            ),
          ),
  );
}
