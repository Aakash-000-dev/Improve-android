import 'package:flutter/material.dart';
import 'glass_card.dart';
import '../models/objective.dart';

class ObjectiveTile extends StatelessWidget {
  const ObjectiveTile({
    super.key,
    required this.objective,
    required this.onChanged,
    this.onEdit,
    this.onDelete,
  });

  final Objective objective;
  final ValueChanged<bool> onChanged;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return GlassCard(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        child: Row(
          children: [
            Checkbox(
              value: objective.done,
              onChanged: (value) => onChanged(value ?? false),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
            ),
            Expanded(
              child: Text(
                objective.title,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  decoration: objective.done ? TextDecoration.lineThrough : null,
                  color: objective.done ? colors.onSurfaceVariant : colors.onSurface,
                ),
              ),
            ),
            if (onEdit != null)
              IconButton(tooltip: 'Edit', onPressed: onEdit, icon: const Icon(Icons.edit_outlined, size: 19)),
            if (onDelete != null)
              IconButton(tooltip: 'Delete', onPressed: onDelete, icon: Icon(Icons.delete_outline, size: 19, color: colors.error)),
          ],
        ),
      ),
    );
  }
}
