import 'dart:ui';
import 'package:flutter/material.dart';

class GlassCard extends StatelessWidget {
  const GlassCard({super.key, required this.child, this.padding, this.radius = 22});
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: (dark ? const Color(0xFF242633) : Colors.white).withValues(alpha: dark ? .58 : .68),
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: (dark ? Colors.white : Colors.white).withValues(alpha: dark ? .13 : .78)),
            boxShadow: [
              BoxShadow(color: Colors.black.withValues(alpha: dark ? .10 : .035), blurRadius: 24, offset: const Offset(0, 8)),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}
