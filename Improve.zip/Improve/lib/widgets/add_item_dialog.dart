import 'package:flutter/material.dart';

Future<String?> showAddItemDialog(
  BuildContext context, {
  required String title,
  String initialValue = '',
}) {
  final textController = TextEditingController(text: initialValue);
  return showDialog<String>(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: textController,
        autofocus: true,
        maxLength: 120,
        decoration: const InputDecoration(hintText: 'Enter a name'),
        onSubmitted: (_) => Navigator.pop(context, textController.text.trim()),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(context, textController.text.trim()), child: const Text('Save')),
      ],
    ),
  ).whenComplete(textController.dispose);
}
