import 'package:flutter/material.dart';
import '../state/improve_controller.dart';
import '../screens/calendar_screen.dart';
import '../screens/home_screen.dart';
import '../screens/notes_screen.dart';
import '../screens/planner_screen.dart';
import '../screens/settings_screen.dart';
import '../screens/statistics_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.controller});
  final ImproveController controller;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final screens = [
      HomeScreen(controller: widget.controller),
      CalendarScreen(controller: widget.controller),
      NotesScreen(controller: widget.controller),
      PlannerScreen(controller: widget.controller),
      StatisticsScreen(controller: widget.controller),
      SettingsScreen(controller: widget.controller),
    ];
    const destinations = [
      NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
      NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'Calendar'),
      NavigationDestination(icon: Icon(Icons.sticky_note_2_outlined), label: 'Notes'),
      NavigationDestination(icon: Icon(Icons.event_note_outlined), label: 'Planner'),
      NavigationDestination(icon: Icon(Icons.insights_outlined), label: 'Stats'),
      NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Settings'),
    ];
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: dark
              ? const [Color(0xFF171927), Color(0xFF10121B), Color(0xFF202039)]
              : const [Color(0xFFF8F8FF), Color(0xFFEEF0FA), Color(0xFFE7E9F8)],
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(child: IndexedStack(index: selectedIndex, children: screens)),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedIndex,
          onDestinationSelected: (index) => setState(() => selectedIndex = index),
          destinations: destinations,
          height: 68,
          labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
        ),
      ),
    );
  }
}
