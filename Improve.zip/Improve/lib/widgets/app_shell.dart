import 'package:flutter/material.dart';
import '../state/improve_controller.dart';
import '../screens/about_screen.dart';
import '../screens/calendar_screen.dart';
import '../screens/home_screen.dart';
import '../screens/notes_screen.dart';
import '../screens/planner_screen.dart';
import '../screens/routines_screen.dart';
import '../screens/settings_screen.dart';
import '../screens/statistics_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.controller});
  final ImproveController controller;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final screens = [
      HomeScreen(controller: widget.controller),
      RoutinesScreen(controller: widget.controller),
      CalendarScreen(controller: widget.controller),
      NotesScreen(controller: widget.controller),
      PlannerScreen(controller: widget.controller),
      StatisticsScreen(controller: widget.controller),
      SettingsScreen(controller: widget.controller),
      AboutScreen(),
    ];

    const destinations = [
      NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
      NavigationDestination(icon: Icon(Icons.checklist_rounded), label: 'Routines'),
      NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'Calendar'),
      NavigationDestination(icon: Icon(Icons.sticky_note_2_outlined), label: 'Notes'),
      NavigationDestination(icon: Icon(Icons.event_note_outlined), label: 'Planner'),
      NavigationDestination(icon: Icon(Icons.insights_outlined), label: 'Stats'),
      NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Settings'),
      NavigationDestination(icon: Icon(Icons.info_outline), label: 'About'),
    ];

    return Scaffold(
      body: SafeArea(
        child: IndexedStack(
          index: selectedIndex,
          children: screens,
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (index) => setState(() => selectedIndex = index),
        destinations: destinations,
      ),
    );
  }
}
