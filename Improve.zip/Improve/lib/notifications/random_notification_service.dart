import 'dart:math';

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter_timezone/flutter_timezone.dart';

/// Schedules a rolling seven-day set of locally generated notification times.
/// Android may defer inexact alarms because of Doze and battery restrictions.
class RandomNotificationService {
  RandomNotificationService._();
  static final RandomNotificationService instance = RandomNotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  static const List<String> messages = [
    'Start where you are. Use what you have. Do what you can.',
    'Small progress is still progress. Keep moving.',
    'Your future benefits from the work you do today.',
    'Focus on the next useful step, not the entire mountain.',
    'Consistency beats waiting for the perfect mood.',
    'Take a breath, reset your focus, and continue.',
    'Make the next 20 minutes count.',
    'You do not need a perfect day to make a meaningful one.',
    'Check your priorities. Is your time going where it matters?',
    'A little discipline today makes tomorrow easier.',
    'Pause the distractions. Return to what matters.',
    'Progress comes from showing up repeatedly.',
  ];

  Future<void> initialize() async {
    if (_initialized) return;
    tzdata.initializeTimeZones();

    // `timezone` defaults to UTC unless the device's IANA timezone is set.
    // Using UTC here would shift active hours and scheduled reminders.
    final deviceTimezone = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(deviceTimezone.identifier));

    const settings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    );
    await _plugin.initialize(settings);
    _initialized = true;
  }

  Future<bool> requestPermission() async {
    await initialize();
    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    return await android?.requestNotificationsPermission() ?? false;
  }

  /// Shows an immediate notification when the user completes an objective
  /// or checkpoint. Completion notifications follow the app's Reminders toggle.
  Future<void> showTaskCompleted({
    required String taskTitle,
    required bool isCheckpoint,
  }) async {
    if (taskTitle.trim().isEmpty) return;
    await initialize();

    final notificationId = 1000000000 +
        DateTime.now().microsecondsSinceEpoch.remainder(1000000000);

    await _plugin.show(
      notificationId,
      isCheckpoint ? 'Checkpoint completed' : 'Objective completed',
      taskTitle,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'improve_task_completed',
          'Task completion',
          channelDescription: 'Confirmation when you complete an objective or checkpoint',
          importance: Importance.high,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
          playSound: true,
        ),
      ),
      payload: 'task_completed',
    );
  }

  Future<void> cancelAll() async {
    await initialize();
    await _plugin.cancelAll();
  }

  Future<void> scheduleSevenDays({
    required bool enabled,
    required int minIntervalMinutes,
    required int maxIntervalMinutes,
    required int startHour,
    required int endHour,
    required int dailyLimit,
  }) async {
    await initialize();
    await _plugin.cancelAll();
    if (!enabled) return;

    final now = DateTime.now();
    final random = Random();
    final shuffledMessages = [...messages]..shuffle(random);
    var messageIndex = 0;
    var notificationId = 1000;

    for (var dayOffset = 0; dayOffset < 7; dayOffset++) {
      final day = DateTime(now.year, now.month, now.day + dayOffset);
      var cursor = DateTime(day.year, day.month, day.day, startHour);
      final windowEnd = DateTime(day.year, day.month, day.day, endHour);

      if (dayOffset == 0 && cursor.isBefore(now.add(const Duration(minutes: 2)))) {
        cursor = now.add(const Duration(minutes: 2));
      }

      var scheduledToday = 0;
      while (scheduledToday < dailyLimit) {
        final delay = minIntervalMinutes +
            random.nextInt(max(1, maxIntervalMinutes - minIntervalMinutes + 1));
        cursor = cursor.add(Duration(minutes: delay));
        if (!cursor.isBefore(windowEnd)) break;

        final message = shuffledMessages[messageIndex % shuffledMessages.length];
        messageIndex++;
        final scheduled = tz.TZDateTime.from(cursor, tz.local);

        await _plugin.zonedSchedule(
          notificationId++,
          'Improve',
          message,
          scheduled,
          const NotificationDetails(
            android: AndroidNotificationDetails(
              'improve_random_messages',
              'Random motivation',
              channelDescription: 'Occasional messages from Improve',
              importance: Importance.defaultImportance,
              priority: Priority.defaultPriority,
              icon: '@mipmap/ic_launcher',
            ),
          ),
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          payload: 'random_motivation',
        );
        scheduledToday++;
      }
    }
  }
}
