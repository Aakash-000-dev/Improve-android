# Android launcher icon configuration

The launcher icon is already included at `assets/icon/app_icon.png`.

The following configuration is included in `pubspec.yaml`:

```yaml
dev_dependencies:
  flutter_launcher_icons: ^0.14.4

flutter_launcher_icons:
  android: true
  ios: false
  image_path: "assets/icon/app_icon.png"
  min_sdk_android: 21
```

Generate Android launcher icon resources from the project root:

```bash
flutter pub get
dart run flutter_launcher_icons
```

Then build the release APK:

```bash
flutter build apk --release
```

For GitHub Actions, make sure the workflow runs the icon-generation command after `flutter pub get` and before `flutter build apk --release`.

Keep the repository's existing `android/` and `.github/` folders when merging this source package into an existing project.
