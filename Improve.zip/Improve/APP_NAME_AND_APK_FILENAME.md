# Set the installed app name and APK filename

## 1. Installed app name: `Improve`

The Android launcher name is controlled by `android:label` in the Android manifest,
not by the Flutter `pubspec.yaml` project name.

This package includes:

`android/app/src/main/res/values/strings.xml`

It defines:

```xml
<string name="app_name">Improve</string>
```

In your existing `android/app/src/main/AndroidManifest.xml`, find the `<application>`
tag and set:

```xml
android:label="@string/app_name"
```

Do not replace the entire manifest. Preserve all existing permissions, activity,
icon references, and other attributes. A short exact instruction is also in
`android/APP_NAME_MANIFEST_CHANGE.txt`.

## 2. APK filename: `Improve.apk`

Flutter's default release output is `app-release.apk`. This is normal. To give the
file the desired name, add the steps from
`github-actions/apk-output-name-step.yml` to your existing workflow after
`flutter build apk --release` and before artifact upload.

The resulting downloaded file will be `Improve.apk`, and the GitHub Actions
artifact will be named `Improve-Android`.

Do not create a second workflow if you already have one. Add the two steps to the
existing workflow instead.

## 3. Rebuild and reinstall

Push the changes and download the newly built `Improve.apk`. Install that build
to see the updated app name. Android may keep the previous label until the new
APK is installed. Keep the same application ID/package name to update the
existing installation rather than creating a separate app.
