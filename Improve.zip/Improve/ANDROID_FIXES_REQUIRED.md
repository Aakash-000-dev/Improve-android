# Android integration required for data restore and notifications

This source archive does not contain the complete generated Android app manifest or
Gradle project. Merge these settings into the existing files. Do not replace your
manifest or generated Android project with a new one.

## 1. AndroidManifest.xml

File: `android/app/src/main/AndroidManifest.xml`

Add these permissions directly below the opening `<manifest ...>` tag:

```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
```

Inside the existing `<application ...>` opening tag, add these attributes (keep all
existing attributes such as `android:label`, `android:icon`, and `android:name`):

```xml
android:allowBackup="true"
android:fullBackupContent="@xml/backup_rules"
android:dataExtractionRules="@xml/data_extraction_rules"
```

Inside the existing `<application>` element, add:

```xml
<receiver
    android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"
    android:exported="false" />

<receiver
    android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver"
    android:exported="false">
    <intent-filter>
        <action android:name="android.intent.action.BOOT_COMPLETED" />
        <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
        <action android:name="android.intent.action.QUICKBOOT_POWERON" />
        <action android:name="com.htc.intent.action.QUICKBOOT_POWERON" />
    </intent-filter>
</receiver>
```

Do not add duplicate receiver declarations if the plugin or your existing manifest
already declares them.

The ZIP now includes:
- `android/app/src/main/res/xml/backup_rules.xml`
- `android/app/src/main/res/xml/data_extraction_rules.xml`

These are used by the manifest attributes above.

## 2. What reinstall backup can and cannot guarantee

Android Auto Backup can restore the SQLite database after reinstall only when:
- Android backup is enabled on the device and a backup has actually completed;
- the user reinstalls with the same package/application ID;
- Android can restore from the same Google/device backup account.

It is not an immediate, guaranteed local copy. A first install may not yet have a backup.
If the app is uninstalled before Android backs it up, the data may be lost.

A normal in-place update should preserve app-private data. If it does not, compare the
old and new APK's application ID/package name and signing certificate. Changing either
can make Android treat the new APK as a different app or reject it as an update.

## 3. Notification changes in this source

- The app now reads the device's IANA timezone before scheduling. The timezone package
  otherwise defaults to UTC, which can put notifications outside the configured hours.
- Android 13+ notification permission is treated as denied if the Android permission
  API is unavailable, instead of silently reporting success.
- Scheduling remains an inexact rolling seven-day schedule. Android may delay it.
- The app must be opened periodically to generate the next seven-day window.
- The boot receiver restores scheduled notifications after reboot or app replacement,
  provided the manifest entries above are merged correctly.

## 4. Build

Run from the Flutter project root:

```bash
flutter pub get
flutter analyze
dart run flutter_launcher_icons
flutter build apk --release
```

Do not uninstall the currently installed app while testing an update. Install the new
APK over the existing installation first. Test reinstall restore separately only after
confirming Android Auto Backup has completed.
