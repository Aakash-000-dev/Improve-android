# Android notification setup

Use `ANDROID_FIXES_REQUIRED.md` for the current manifest permissions and receiver
configuration. That file also documents Android Auto Backup settings.

The scheduler uses inexact alarms and a rolling seven-day window. Android may defer
notifications due to Doze, battery management, notification permission settings, or
manufacturer restrictions. Open Improve periodically so it can prepare the next
seven-day schedule.


## Task-completion notifications
The app also displays an immediate notification when an objective or checkpoint is newly checked off for the current day. This uses the `Task completion` notification channel and follows the existing **Reminders** setting. Make sure Android notification permission is granted for Improve and that this channel is not muted in Android Settings > Apps > Improve > Notifications. Unchecking an item or completing an item on a historical date does not trigger this notification.
