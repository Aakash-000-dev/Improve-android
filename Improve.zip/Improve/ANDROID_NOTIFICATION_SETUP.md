# Android notification integration

The Flutter notification package is configured in `pubspec.yaml`. The source archive
does not replace your complete Android manifest or Gradle files. Merge the following
into the existing `android/app/src/main/AndroidManifest.xml`.

Add these permissions directly under the root `<manifest>` element:

```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
```

Inside the existing `<application>` element, add these receivers. Do not remove
your existing `<activity>`, application name, icon, or other configuration:

```xml
<receiver
    android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"
    android:exported="false" />

<receiver
    android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver"
    android:exported="false">
    <intent-filter>
        <action android:name="android.intent.action.BOOT_COMPLETED" />
        <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
        <action android:name="android.intent.action.QUICKBOOT_POWERON" />
        <action android:name="com.htc.intent.action.QUICKBOOT_POWERON" />
    </intent-filter>
</receiver>
```

The implementation schedules inexact notifications, so it does not request exact-alarm
access. Android 13 and later asks for notification permission when the user enables
Random messages. Android can still delay or suppress delivery due to battery settings,
Do Not Disturb, user permission choices, or manufacturer background restrictions.

## Scheduling behaviour

- A fixed built-in pool of motivational messages is stored in the app source.
- Random intervals are generated between the configured minimum and maximum.
- Notifications are limited to the configured local-time active window and daily cap.
- The app prepares a rolling seven-day schedule on launch and whenever settings change.
- The plugin's boot receiver restores pending scheduled notifications after device restart.
- If the user does not open the app again after the seven-day schedule expires, no new
  schedule can be generated. This version does not run a permanent background Dart service.

## Build

From the Flutter project root:

```bash
flutter pub get
flutter analyze
dart run flutter_launcher_icons
flutter build apk --release
```

If your Android project uses an older Gradle setup, follow the package's current
Android setup requirements before building. Do not replace the whole manifest with
the snippet above.
