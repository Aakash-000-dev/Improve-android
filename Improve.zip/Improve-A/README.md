# Improve Flutter Starter

This is the first UI prototype for Improve, built with Flutter and Dart. It intentionally uses only Flutter SDK widgets, so there are no third-party runtime packages to download yet.

## Included
- Home progress dashboard
- Routines and checkpoints with add/edit/delete
- Calendar month grid and selected date
- Daily notes screen
- Global planner screen
- Basic statistics
- System/light/dark theme selector
- Settings and About screens
- Responsive Material 3 UI

## Important prototype limitations
- Data is currently stored in memory and resets when the app closes.
- Notes and global planner save only for the current running session.
- The calendar changes the selected date, but historical objective records are not yet implemented.
- Reminder toggle is a UI placeholder; it does not schedule Android notifications.
- Default routines are not yet separated from daily records.
- This is a UI foundation, not a production-ready release.

## Use it in a Flutter project
1. Install Flutter and VS Code's Flutter extension.
2. In a terminal, create a project:
   ```powershell
   flutter create improve
   ```
3. Replace the generated `pubspec.yaml` with this package's `pubspec.yaml`.
4. Copy this package's `lib` folder into the project, replacing the generated `lib` folder.
5. From the project directory, run:
   ```powershell
   flutter pub get
   flutter run -d chrome
   ```

For Android, connect a phone with USB debugging enabled or configure an Android build environment, then use `flutter devices` and `flutter run -d <device-id>`. APK packaging will be verified early before expanding the project.

## Next phase
Add SQLite persistence and a proper daily-record schema, then implement Android notification scheduling and test the built APK on a real phone.
