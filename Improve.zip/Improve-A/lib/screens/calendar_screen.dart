import 'package:flutter/material.dart';
import '../state/improve_controller.dart';
import '../widgets/section_header.dart';

class CalendarScreen extends StatelessWidget {
  const CalendarScreen({super.key, required this.controller});
  final ImproveController controller;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: controller,
    builder: (context, _) {
      final date = controller.selectedDate;
      return ListView(
        padding: const EdgeInsets.fromLTRB(20, 22, 20, 28),
        children: [
          const SectionHeader(title: 'Calendar', subtitle: 'Choose a day to review its record.'),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(onPressed: () => controller.selectDate(DateTime(date.year, date.month - 1, 1)), icon: const Icon(Icons.chevron_left)),
                      Expanded(child: Center(child: Text(_monthYear(date), style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)))),
                      IconButton(onPressed: () => controller.selectDate(DateTime(date.year, date.month + 1, 1)), icon: const Icon(Icons.chevron_right)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Row(
                    children: [
                      for (final day in ['M', 'T', 'W', 'T', 'F', 'S', 'S'])
                        Expanded(child: Center(child: Text(day))),
                    ],
                  ),
                  const SizedBox(height: 10),
                  _MonthGrid(
                    year: date.year,
                    month: date.month,
                    selectedDay: date.day,
                    onSelect: (day) => controller.selectDate(DateTime(date.year, date.month, day)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          Card(
            child: ListTile(
              leading: const Icon(Icons.event_available_outlined),
              title: Text(_fullDate(date)),
              subtitle: const Text('Daily history storage will be connected in the database phase.'),
            ),
          ),
        ],
      );
    },
  );

  static String _monthYear(DateTime date) => '${_months[date.month - 1]} ${date.year}';
  static String _fullDate(DateTime date) => '${_months[date.month - 1]} ${date.day}, ${date.year}';
}

const _months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

class _MonthGrid extends StatelessWidget {
  const _MonthGrid({required this.year, required this.month, required this.selectedDay, required this.onSelect});
  final int year;
  final int month;
  final int selectedDay;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    final firstWeekday = DateTime(year, month, 1).weekday;
    final daysInMonth = DateTime(year, month + 1, 0).day;
    final cells = <Widget>[];
    for (var i = 1; i < firstWeekday; i++) {
      cells.add(const SizedBox(height: 42));
    }
    for (var day = 1; day <= daysInMonth; day++) {
      final selected = day == selectedDay;
      cells.add(
        InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => onSelect(day),
          child: Container(
            height: 42,
            margin: const EdgeInsets.all(2),
            decoration: BoxDecoration(
              color: selected ? Theme.of(context).colorScheme.primary : Colors.transparent,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Center(
              child: Text('$day', style: TextStyle(
                fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                color: selected ? Theme.of(context).colorScheme.onPrimary : null,
              )),
            ),
          ),
        ),
      );
    }
    return GridView.count(
      crossAxisCount: 7,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 1,
      children: cells,
    );
  }
}
