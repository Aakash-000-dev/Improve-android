import 'package:flutter/material.dart';
import 'package:workmanager/workmanager.dart';
import 'app/improve_app.dart';
import 'notifications/notification_background_worker.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Workmanager().initialize(improveWorkmanagerCallbackDispatcher);
  runApp(const ImproveApp());
}
