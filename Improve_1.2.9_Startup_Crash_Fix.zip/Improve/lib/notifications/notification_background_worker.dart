import 'package:workmanager/workmanager.dart';
import 'random_notification_service.dart';

const String improveNotificationRefreshTask = 'improve.notification.refresh';
const String improveNotificationRefreshUniqueName = 'improve.notification.refresh.daily';

/// Runs in a background isolate. WorkManager may defer this task, so it is
/// used only to replenish a rolling schedule, never for exact-time alarms.
@pragma('vm:entry-point')
void improveWorkmanagerCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task != improveNotificationRefreshTask) return true;
    try {
      final enabled = inputData?['enabled'] == true;
      if (!enabled) {
        await RandomNotificationService.instance.cancelAll();
        return true;
      }
      await RandomNotificationService.instance.scheduleSevenDays(
        enabled: true,
        minIntervalMinutes: (inputData?['minIntervalMinutes'] as num?)?.toInt() ?? 60,
        maxIntervalMinutes: (inputData?['maxIntervalMinutes'] as num?)?.toInt() ?? 180,
        startHour: (inputData?['startHour'] as num?)?.toInt() ?? 8,
        endHour: (inputData?['endHour'] as num?)?.toInt() ?? 21,
        dailyLimit: (inputData?['dailyLimit'] as num?)?.toInt() ?? 5,
      );
      return true;
    } catch (_) {
      return false;
    }
  });
}
