import 'package:flutter/material.dart';
import 'package:workmanager/workmanager.dart';
import 'app/improve_app.dart';
import 'notifications/notification_background_worker.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // WorkManager is an optional enhancement. If its Android plugin cannot
  // initialize on a device/build, Improve must still launch normally.
  try {
    await Workmanager().initialize(improveWorkmanagerCallbackDispatcher);
  } catch (error, stackTrace) {
    // Do not let background scheduling prevent the main app from opening.
    debugPrint('WorkManager initialization failed: $error');
    debugPrintStack(stackTrace: stackTrace);
  }
  runApp(const ImproveApp());
}
