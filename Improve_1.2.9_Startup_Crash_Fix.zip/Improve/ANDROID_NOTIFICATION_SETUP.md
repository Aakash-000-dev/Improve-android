# Improve Android notifications (1.2.9)

Improve uses `flutter_local_notifications` for displaying and scheduling motivational messages, and Android WorkManager for a daily background refresh of the rolling seven-day schedule. WorkManager is intentionally not used as the clock for individual notifications because Android may defer background work.

## Android manifest requirements

The generated `android/app/src/main/AndroidManifest.xml` must include these permissions under `<manifest>`:

```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
```

Inside `<application>`, retain the app's existing activity and add:

```xml
<receiver android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" android:exported="false" />
<receiver android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver" android:exported="false">
  <intent-filter>
    <action android:name="android.intent.action.BOOT_COMPLETED" />
    <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
    <action android:name="android.intent.action.QUICKBOOT_POWERON" />
    <action android:name="com.htc.intent.action.QUICKBOOT_POWERON" />
  </intent-filter>
</receiver>
```

WorkManager's Android components are merged from its Flutter plugin. Do not manually declare duplicate WorkManager receivers.

## Behaviour and limitations

- App launch/settings changes immediately create a rolling seven-day motivational schedule.
- When enabled, WorkManager attempts to refresh that schedule every 24 hours, even if Improve has not been opened.
- WorkManager timing is inexact and Android may defer it. It is not an exact alarm and does not guarantee a notification at a precise minute.
- The local notification boot receiver restores pending scheduled notifications after restart.
- Android 13+ requires notification permission. Battery restrictions, Do Not Disturb, force-stop, and manufacturer policies can still affect delivery.
- No network access is required.
