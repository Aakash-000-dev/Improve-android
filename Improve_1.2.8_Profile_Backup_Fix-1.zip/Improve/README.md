# Improve 1.2.0

Improve is an offline-first Flutter routine and planning app. This update adds local SQLite persistence and a restrained glassmorphism visual system.

## What's upgraded

### Local database
- SQLite database file: `improve.db` in the platform's application database directory.
- Default objectives and checkpoints are stored separately from daily records.
- The first time a date is opened, its daily objectives/checkpoints are copied from the current defaults.
- Existing dates are not rewritten when defaults are edited, added, or removed.
- Completion state is stored per date and per item.
- Daily notes are stored by date.
- Global Planner content is stored separately from daily notes.
- Theme, random-notification preferences and scheduling limits are persisted locally.
- Database operations use parameterized sqflite queries and transactions for first-day creation.

### Interface
- Reusable frosted-glass panels with blur, translucent surfaces, subtle borders and shadows.
- Soft gradient page background.
- Updated light and dark palettes.
- System/light/dark appearance selection remains available.
- Text contrast is kept readable; blur is restrained to avoid turning every screen into a fog machine.

## Project setup

This ZIP contains the Flutter project source files. If you already have the generated `android/` folder and GitHub Actions workflow in your working project, keep them. Copy/merge this ZIP's `lib/` and `pubspec.yaml` into that project rather than deleting its platform folders or workflow files.

From the project root:

```powershell
flutter pub get
flutter analyze
```

For an Android device or a cloud APK build, use your existing Android build workflow. The new database dependency is `sqflite` and the path helper is `path`.

## Database behaviour

- Defaults are templates for dates that have not been initialized yet.
- When a date is initialized for the first time, active defaults are copied into `daily_items` and the date is recorded in `initialized_days`.
- Later changes to defaults do not mutate that date's records.
- Adding/editing/deleting a routine from the Routines screen changes only the selected date's daily record.
- Deleting a default removes it from future templates without deleting historical daily items.

## Random message notifications

- A built-in pool of motivational messages is scheduled at randomly generated intervals.
- Settings include minimum/maximum interval, active hours and a daily limit.
- The app prepares a rolling seven-day schedule. Android may delay inexact notifications.
- Add the manifest permissions and receivers described in `ANDROID_NOTIFICATION_SETUP.md`.
- The app must be opened again to refresh the schedule after the seven-day window expires; this is not a permanent background service.

## Current limitations

- This build uses `sqflite`, which targets Android/iOS/macOS. The Chrome web preview is not a supported runtime for the SQLite implementation.
- Random local notifications are implemented using a rolling seven-day schedule. Android delivery is best-effort and can be delayed by battery management or user settings.
- Statistics currently summarize the selected day's objectives. Trend charts and cross-date analytics are not implemented.
- No cloud sync or database export/backup is included. App data is local to the device; uninstalling the app may remove it.
- The source ZIP does not include generated Android platform files or your GitHub Actions workflow. Preserve those from your existing project.

## Suggested verification

1. Add an objective and checkpoint for today, then mark them complete.
2. Save a daily note and Global Planner text.
3. Close and reopen the app; confirm all three persist.
4. Open a different date and confirm it receives the current defaults.
5. Change a default in Settings, then reopen an older date and confirm its saved list is unchanged.
6. Build and install the APK on the same phone before replacing your previous release.

## Android app name and APK filename

See [APP_NAME_AND_APK_FILENAME.md](APP_NAME_AND_APK_FILENAME.md) to set the
installed app name to `Improve` and rename the GitHub Actions APK artifact to
`Improve.apk`. The Android manifest change must be applied to your existing
`android/` project, which is not otherwise included in this source archive.

## Offline database backup and restore

Open **Settings → Data backup**.

- **Export backup** creates a portable `Improve_backup_*.json` file containing defaults, initialized dates, daily objectives/checkpoints, notes, planner content, and app settings.
- Save the file to a location outside the Improve app folder (for example, Downloads, Documents, or an external drive). A file kept only in app-private storage may be deleted when Improve is uninstalled.
- **Restore backup** selects a previously exported JSON backup. Restoring replaces the current database contents, so export the current data first if you may need it.
- The backup and restore process itself works without an internet connection.

This is a manual export/import implementation. It does not yet perform automatic scheduled backups or cloud synchronization.


## Profile
The Profile tab replaces Settings in bottom navigation. Settings are opened from the Profile screen. Profile name, bio, birthday, and selected profile image are stored in the `app_settings` table as a `profile` JSON value, so the existing backup service includes them in exported backups and restores them with the rest of the app data. Profile images are limited to 2 MB.
