## 1.2.8+12
- Fixed profile data being omitted or not reapplied during ZIP backup restoration.
- Profile is now stored explicitly in the backup payload and restored into app_settings.

# Changelog

## 1.2.8+11
- Replaced JSON-only exports with genuine ZIP backup archives.
- Added a dedicated Backup & Restore destination inside Profile.
- Added a one-time restore offer on a fresh installation.
- Added optional profile reminders after three app sessions, repeating every three sessions until profile setup.
- Preserved existing local data tables and profile image backup support.

- Fixed Flutter timezone API usage: getLocalTimezone() is treated as a String.

## 1.2.6+9
- Fixed device timezone initialization for notification scheduling.
- Normalized Asia/Calcutta to Asia/Kolkata with a safe fallback.

# Changelog

## 1.1.0+2
- Added SQLite persistence for daily routines, checkpoints, notes, Global Planner, defaults and preferences.
- Added per-date initialization so default changes do not rewrite existing day records.
- Added reusable frosted-glass panels and updated light/dark themes.
- Updated settings to manage default objectives and checkpoints independently from the selected day's routine.
- Updated save confirmations and About information.

## 1.2.0
- Added predefined random motivational notifications.
- Added configurable random interval range, active hours and daily cap.
- Added rolling seven-day local notification scheduling and Android restart integration instructions.
