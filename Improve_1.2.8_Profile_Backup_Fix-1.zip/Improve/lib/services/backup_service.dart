import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:sqflite/sqflite.dart';

import '../database/database_helper.dart';

/// Creates and restores a real ZIP archive containing a portable SQLite-data export.
class BackupService {
  BackupService._();
  static final BackupService instance = BackupService._();
  static const int formatVersion = 1;
  static const String _payloadName = 'improve_data.json';
  static const List<String> _tables = [
    'defaults', 'initialized_days', 'daily_items', 'notes', 'planner', 'app_settings',
  ];

  Future<Uint8List> createBackup() async {
    final db = await DatabaseHelper.instance.database;
    final data = <String, Object?>{};
    await db.transaction((txn) async {
      for (final table in _tables) {
        data[table] = await txn.query(table);
      }
    });
    // Profile is stored in app_settings as JSON. Also place it in a dedicated
    // top-level field so profile export is explicit and can be restored even
    // when importing a backup created by a build with an incomplete table export.
    Map<String, Object?>? profileData;
    final settingsRows = data['app_settings'] as List<Map<String, Object?>>;
    for (final row in settingsRows) {
      if (row['key'] == 'profile' && row['value'] is String) {
        try {
          final decodedProfile = jsonDecode(row['value'] as String);
          if (decodedProfile is Map) {
            profileData = Map<String, Object?>.from(decodedProfile);
          }
        } catch (_) {
          // Keep the raw settings row; restore validation will not invent profile data.
        }
        break;
      }
    }
    final document = <String, Object?>{
      'app': 'Improve',
      'backupFormatVersion': formatVersion,
      'createdAt': DateTime.now().toUtc().toIso8601String(),
      'databaseSchemaVersion': await db.getVersion(),
      'profile': profileData,
      'tables': data,
    };
    final payload = Uint8List.fromList(utf8.encode(const JsonEncoder.withIndent('  ').convert(document)));
    final manifest = Uint8List.fromList(utf8.encode(jsonEncode({
      'app': 'Improve',
      'archiveFormat': 'improve-zip-backup',
      'archiveVersion': formatVersion,
      'payload': _payloadName,
      'createdAt': DateTime.now().toUtc().toIso8601String(),
    })));
    final archive = Archive()
      ..addFile(ArchiveFile('manifest.json', manifest.length, manifest))
      ..addFile(ArchiveFile(_payloadName, payload.length, payload));
    final encoded = ZipEncoder().encode(archive);
    if (encoded.isEmpty) throw StateError('Could not create the ZIP backup archive.');
    return Uint8List.fromList(encoded);
  }

  Future<void> restoreBackup(Uint8List bytes) async {
    if (bytes.length < 4 || bytes[0] != 0x50 || bytes[1] != 0x4B) {
      throw const FormatException('Select a genuine Improve .zip backup file.');
    }
    final Archive archive;
    try {
      archive = ZipDecoder().decodeBytes(bytes, verify: true);
    } catch (_) {
      throw const FormatException('The ZIP backup is damaged or cannot be opened.');
    }
    final files = <String, ArchiveFile>{
      for (final file in archive.files)
        if (!file.isDirectory) file.name: file,
    };
    final manifestFile = files['manifest.json'];
    final payloadFile = files[_payloadName];
    if (manifestFile == null || payloadFile == null) {
      throw const FormatException('This ZIP does not contain a valid Improve backup.');
    }
    final manifestBytes = manifestFile.content;
    final payloadBytes = payloadFile.content;
    final dynamic manifest;
    final dynamic decoded;
    try {
      manifest = jsonDecode(utf8.decode(manifestBytes));
      decoded = jsonDecode(utf8.decode(payloadBytes));
    } catch (_) {
      throw const FormatException('The Improve backup contents are not valid.');
    }
    if (manifest is! Map || manifest['app'] != 'Improve' ||
        manifest['archiveFormat'] != 'improve-zip-backup' ||
        manifest['archiveVersion'] != formatVersion) {
      throw const FormatException('This is not a supported Improve ZIP backup.');
    }
    if (decoded is! Map<String, dynamic> || decoded['app'] != 'Improve' ||
        decoded['backupFormatVersion'] != formatVersion ||
        decoded['tables'] is! Map<String, dynamic>) {
      throw const FormatException('The backup data format is not supported.');
    }
    final tables = decoded['tables'] as Map<String, dynamic>;
    for (final table in _tables) {
      final rows = tables[table];
      if (rows is! List || rows.any((row) => row is! Map)) {
        throw FormatException('Backup is missing valid "$table" data.');
      }
    }

    // New backups carry profile data both in app_settings and in this explicit
    // field. Prefer the explicit field and inject it into app_settings before
    // the database transaction. Older backups without this field still restore
    // their profile from the app_settings table as before.
    final explicitProfile = decoded['profile'];
    if (explicitProfile != null) {
      if (explicitProfile is! Map) {
        throw const FormatException('The profile data in this backup is invalid.');
      }
      final settingsRows = (tables['app_settings'] as List)
          .map((row) => Map<String, Object?>.from(row as Map))
          .toList();
      settingsRows.removeWhere((row) => row['key'] == 'profile');
      settingsRows.add({
        'key': 'profile',
        'value': jsonEncode(Map<String, Object?>.from(explicitProfile)),
      });
      tables['app_settings'] = settingsRows;
    }

    final db = await DatabaseHelper.instance.database;
    // All content is parsed before this transaction. Any insert/integrity failure
    // rolls back the complete replacement, leaving the existing database intact.
    await db.transaction((txn) async {
      for (final table in ['daily_items', 'initialized_days', 'notes', 'planner', 'app_settings', 'defaults']) {
        await txn.delete(table);
      }
      for (final table in _tables) {
        for (final rawRow in tables[table] as List) {
          await txn.insert(table, Map<String, Object?>.from(rawRow as Map), conflictAlgorithm: ConflictAlgorithm.abort);
        }
      }
      // Do not make the freshly restored installation ask for the same backup again.
      await txn.insert('app_settings', {'key': 'install_restore_pending', 'value': '0'}, conflictAlgorithm: ConflictAlgorithm.replace);
      final integrity = await txn.rawQuery('PRAGMA quick_check');
      if (integrity.isEmpty || integrity.first.values.first != 'ok') {
        throw StateError('Restored database failed its integrity check.');
      }
    });
  }
}
