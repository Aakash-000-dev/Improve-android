import 'dart:convert';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../state/improve_controller.dart';
import '../widgets/glass_card.dart';
import 'settings_screen.dart';
import 'backup_restore_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key, required this.controller, this.startEditing = false});
  final ImproveController controller;
  final bool startEditing;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late final TextEditingController _name;
  late final TextEditingController _bio;
  String _birthday = '';
  String _imageBase64 = '';
  bool _editing = false;

  @override
  void initState() {
    super.initState();
    final profile = widget.controller.profile;
    _name = TextEditingController(text: profile['name']?.toString() ?? '');
    _bio = TextEditingController(text: profile['bio']?.toString() ?? '');
    _birthday = profile['birthday']?.toString() ?? '';
    _imageBase64 = profile['imageBase64']?.toString() ?? '';
    _editing = widget.startEditing;
  }

  @override
  void dispose() {
    _name.dispose();
    _bio.dispose();
    super.dispose();
  }

  Future<void> _chooseImage() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final bytes = result.files.single.bytes;
    if (bytes == null) return;
    if (bytes.length > 2 * 1024 * 1024) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Choose an image smaller than 2 MB.')),
        );
      }
      return;
    }
    setState(() => _imageBase64 = base64Encode(bytes));
  }

  Future<void> _chooseBirthday() async {
    final now = DateTime.now();
    final initial = DateTime.tryParse(_birthday) ?? DateTime(now.year - 15, now.month, now.day);
    final picked = await showDatePicker(
      context: context,
      initialDate: initial.isAfter(now) ? now : initial,
      firstDate: DateTime(1900),
      lastDate: now,
      helpText: 'Select birthday',
    );
    if (picked != null) {
      setState(() => _birthday =
          '${picked.year.toString().padLeft(4, '0')}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}');
    }
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter a name to save your profile.')),
      );
      return;
    }
    await widget.controller.saveProfile(
      name: _name.text,
      bio: _bio.text,
      birthday: _birthday,
      imageBase64: _imageBase64,
    );
    if (mounted) {
      setState(() => _editing = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profile saved.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final profileName = _name.text.trim();
    Uint8List? photo;
    try {
      if (_imageBase64.isNotEmpty) photo = base64Decode(_imageBase64);
    } catch (_) {}
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 30),
      children: [
        Row(
          children: [
            Expanded(
              child: Text('Profile',
                  style: Theme.of(context).textTheme.headlineMedium
                      ?.copyWith(fontWeight: FontWeight.w800)),
            ),
            IconButton.filledTonal(
              tooltip: 'Settings',
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => SettingsScreen(controller: widget.controller),
                ),
              ),
              icon: const Icon(Icons.settings_outlined),
            ),
          ],
        ),
        const SizedBox(height: 18),
        GlassCard(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                GestureDetector(
                  onTap: _editing ? _chooseImage : null,
                  child: CircleAvatar(
                    radius: 48,
                    backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                    backgroundImage: photo == null ? null : MemoryImage(photo),
                    child: photo == null
                        ? Icon(Icons.person_rounded,
                            size: 48,
                            color: Theme.of(context).colorScheme.onPrimaryContainer)
                        : null,
                  ),
                ),
                if (_editing) ...[
                  const SizedBox(height: 8),
                  TextButton.icon(
                    onPressed: _chooseImage,
                    icon: const Icon(Icons.photo_camera_outlined),
                    label: const Text('Choose profile image'),
                  ),
                ],
                const SizedBox(height: 12),
                Text(
                  profileName.isEmpty ? 'Your profile' : profileName,
                  style: Theme.of(context).textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
                if (!_editing && (_bio.text.isNotEmpty || _birthday.isNotEmpty)) ...[
                  if (_bio.text.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(_bio.text, textAlign: TextAlign.center),
                  ],
                  if (_birthday.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text('Birthday: $_birthday',
                        style: Theme.of(context).textTheme.bodySmall),
                  ],
                ],
                const SizedBox(height: 18),
                if (_editing) ...[
                  TextField(
                    controller: _name,
                    maxLength: 40,
                    decoration: const InputDecoration(
                      labelText: 'Name',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _bio,
                    maxLength: 160,
                    maxLines: 3,
                    decoration: const InputDecoration(
                      labelText: 'Bio',
                      hintText: 'A little about you',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.cake_outlined),
                    title: const Text('Birthday'),
                    subtitle: Text(_birthday.isEmpty ? 'Not set' : _birthday),
                    trailing: const Icon(Icons.calendar_month_outlined),
                    onTap: _chooseBirthday,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => setState(() => _editing = false),
                          child: const Text('Cancel'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: FilledButton(
                          onPressed: _save,
                          child: const Text('Save profile'),
                        ),
                      ),
                    ],
                  ),
                ] else
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.tonalIcon(
                      onPressed: () => setState(() => _editing = true),
                      icon: const Icon(Icons.edit_outlined),
                      label: const Text('Edit profile'),
                    ),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        GlassCard(
          child: ListTile(
            leading: const Icon(Icons.archive_outlined),
            title: const Text('Backup & Restore'),
            subtitle: const Text('Export or restore your Improve ZIP backup'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => BackupRestoreScreen(controller: widget.controller)),
            ),
          ),
        ),
        const SizedBox(height: 12),
        GlassCard(
          child: ListTile(
            leading: const Icon(Icons.settings_outlined),
            title: const Text('Settings'),
            subtitle: const Text('Appearance, notifications and defaults'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => SettingsScreen(controller: widget.controller),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          'Your profile is stored locally and is included in Improve ZIP backups, including the profile image.',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }
}
