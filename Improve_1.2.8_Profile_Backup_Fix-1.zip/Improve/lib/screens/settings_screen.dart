import 'package:flutter/material.dart';
import '../state/improve_controller.dart';
import 'about_screen.dart';
import '../widgets/add_item_dialog.dart';
import '../widgets/glass_card.dart';
import '../widgets/section_header.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.controller});
  final ImproveController controller;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Settings')),
    body: SafeArea(child: ListenableBuilder(
    listenable: controller,
    builder: (context, _) => ListView(padding: const EdgeInsets.fromLTRB(20, 22, 20, 30), children: [
      const SectionHeader(title: 'Settings', subtitle: 'Shape your daily starting point.'),
      GlassCard(child: Column(children: [
        ListTile(leading: const Icon(Icons.palette_outlined), title: const Text('Appearance'), subtitle: Text(_themeLabel(controller.themeMode)), trailing: DropdownButton<ThemeMode>(value: controller.themeMode, underline: const SizedBox.shrink(), items: const [DropdownMenuItem(value: ThemeMode.system, child: Text('System')), DropdownMenuItem(value: ThemeMode.light, child: Text('Light')), DropdownMenuItem(value: ThemeMode.dark, child: Text('Dark'))], onChanged: (v) { if (v != null) controller.setThemeMode(v); })),
        const Divider(height: 1, indent: 16, endIndent: 16),
        SwitchListTile(secondary: const Icon(Icons.notifications_none_rounded), title: const Text('Random messages'), subtitle: const Text('Predefined messages at random intervals.'), value: controller.remindersEnabled, onChanged: controller.setReminders),
      ])),
      const SizedBox(height: 12),
      GlassCard(child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Random message schedule', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text('Improve selects a predefined message and schedules it at a random interval. Android may delay delivery to save battery.', style: Theme.of(context).textTheme.bodySmall),
          const Divider(height: 22),
          _numberSetting(context, 'Minimum interval', controller.notificationMinMinutes, const [30, 60, 90, 120, 180, 240, 360], (v) {
            final maxValue = controller.notificationMaxMinutes < v ? v : controller.notificationMaxMinutes;
            controller.setRandomNotificationConfig(minMinutes: v, maxMinutes: maxValue);
          }, suffix: 'min'),
          _numberSetting(context, 'Maximum interval', controller.notificationMaxMinutes, const [30, 60, 90, 120, 180, 240, 360], (v) {
            final minValue = controller.notificationMinMinutes > v ? v : controller.notificationMinMinutes;
            controller.setRandomNotificationConfig(minMinutes: minValue, maxMinutes: v);
          }, suffix: 'min'),
          _numberSetting(context, 'Active from', controller.notificationStartHour, List.generate(15, (i) => i + 6), (v) {
            final end = controller.notificationEndHour <= v ? v + 1 : controller.notificationEndHour;
            controller.setRandomNotificationConfig(startHour: v, endHour: end);
          }, suffix: ':00'),
          _numberSetting(context, 'Active until', controller.notificationEndHour, List.generate(15, (i) => i + 7), (v) {
            final start = controller.notificationStartHour >= v ? v - 1 : controller.notificationStartHour;
            controller.setRandomNotificationConfig(startHour: start, endHour: v);
          }, suffix: ':00'),
          _numberSetting(context, 'Daily limit', controller.notificationDailyLimit, const [1, 2, 3, 4, 5, 6, 7, 8], (v) => controller.setRandomNotificationConfig(dailyLimit: v), suffix: ' / day'),
          const SizedBox(height: 6),
          Text('A rolling 7-day schedule is prepared on app launch and when settings change. Enable notifications above to activate it.', style: Theme.of(context).textTheme.bodySmall),
          if (controller.notificationSetupError != null) ...[
            const SizedBox(height: 8),
            Text('Notification setup issue: ${controller.notificationSetupError}', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).colorScheme.error)),
          ],
        ]),
      )),
      const SizedBox(height: 22),
      _DefaultsSection(title: 'Default objectives', items: controller.defaultObjectives, onAdd: () async { final v = await showAddItemDialog(context, title: 'Add default objective'); if (v != null) controller.addDefault(v); }, onEdit: (row) async { final v = await showAddItemDialog(context, title: 'Edit default objective', initialValue: row['title'] as String); if (v != null) controller.editDefault(row['id'] as int, v); }, onDelete: (row) => controller.deleteDefault(row['id'] as int)),
      const SizedBox(height: 18),
      _DefaultsSection(title: 'Default checkpoints', items: controller.defaultCheckpoints, onAdd: () async { final v = await showAddItemDialog(context, title: 'Add default checkpoint'); if (v != null) controller.addDefault(v, checkpoint: true); }, onEdit: (row) async { final v = await showAddItemDialog(context, title: 'Edit default checkpoint', initialValue: row['title'] as String); if (v != null) controller.editDefault(row['id'] as int, v); }, onDelete: (row) => controller.deleteDefault(row['id'] as int)),
      const SizedBox(height: 14),
      GlassCard(child: ListTile(
        leading: const Icon(Icons.info_outline_rounded),
        title: const Text('About Improve'),
        subtitle: const Text('Version, app information and details'),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AboutScreen())),
      )),
      const SizedBox(height: 14),
      Text('Changes to defaults apply only when a date is opened for the first time. Existing daily records remain unchanged.', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant)),
    ]),
  )),
  );

  String _themeLabel(ThemeMode mode) => switch (mode) { ThemeMode.system => 'Follow device theme', ThemeMode.light => 'Light theme', ThemeMode.dark => 'Dark theme' };
}

Widget _numberSetting(BuildContext context, String title, int value, List<int> options, ValueChanged<int> onChanged, {String suffix = ''}) {
  return ListTile(
    dense: true,
    contentPadding: EdgeInsets.zero,
    title: Text(title),
    trailing: DropdownButton<int>(
      value: options.contains(value) ? value : options.first,
      underline: const SizedBox.shrink(),
      items: options.map((v) => DropdownMenuItem(value: v, child: Text('$v$suffix'))).toList(),
      onChanged: (v) { if (v != null) onChanged(v); },
    ),
  );
}

class _DefaultsSection extends StatelessWidget {
  const _DefaultsSection({required this.title, required this.items, required this.onAdd, required this.onEdit, required this.onDelete});
  final String title;
  final List<Map<String, Object?>> items;
  final VoidCallback onAdd;
  final ValueChanged<Map<String, Object?>> onEdit;
  final ValueChanged<Map<String, Object?>> onDelete;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [Expanded(child: Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800))), IconButton.filledTonal(onPressed: onAdd, icon: const Icon(Icons.add))]),
    const SizedBox(height: 8),
    GlassCard(child: items.isEmpty ? const Padding(padding: EdgeInsets.all(18), child: Text('No defaults yet. Add one to use it on future dates.')) : Column(children: [
      for (var i = 0; i < items.length; i++) ...[
        if (i > 0) const Divider(height: 1, indent: 16, endIndent: 16),
        ListTile(title: Text(items[i]['title'] as String), trailing: Wrap(spacing: 0, children: [IconButton(tooltip: 'Edit', onPressed: () => onEdit(items[i]), icon: const Icon(Icons.edit_outlined, size: 19)), IconButton(tooltip: 'Remove from defaults', onPressed: () => onDelete(items[i]), icon: const Icon(Icons.remove_circle_outline, size: 19))])),
      ],
    ])),
  ]);
}

