import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../services/backup_service.dart';
import '../state/improve_controller.dart';
import '../widgets/glass_card.dart';
import '../widgets/section_header.dart';

class BackupRestoreScreen extends StatelessWidget {
  const BackupRestoreScreen({super.key, required this.controller});
  final ImproveController controller;

  String _stamp() {
    final n = DateTime.now();
    return '${n.year}${n.month.toString().padLeft(2, '0')}${n.day.toString().padLeft(2, '0')}_${n.hour.toString().padLeft(2, '0')}${n.minute.toString().padLeft(2, '0')}';
  }

  Future<void> _export(BuildContext context) async {
    try {
      final bytes = await BackupService.instance.createBackup();
      final path = await FilePicker.platform.saveFile(
        dialogTitle: 'Save Improve ZIP backup',
        fileName: 'Improve_backup_${_stamp()}.zip',
        bytes: bytes,
        type: FileType.custom,
        allowedExtensions: ['zip'],
      );
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(path == null ? 'Backup export cancelled.' : 'ZIP backup saved. Keep it outside the Improve app folder.'),
      ));
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Backup failed: $e')));
    }
  }

  Future<void> _restore(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Restore backup?'),
        content: const Text('This replaces the current Improve data with the data in the ZIP. The current database is protected by a transaction and will remain unchanged if restoration fails.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Choose ZIP')),
        ],
      ),
    );
    if (confirm != true || !context.mounted) return;
    try {
      final result = await FilePicker.platform.pickFiles(
        dialogTitle: 'Choose Improve ZIP backup',
        type: FileType.custom,
        allowedExtensions: ['zip'],
        withData: true,
      );
      if (result == null || result.files.isEmpty) return;
      final bytes = result.files.single.bytes;
      if (bytes == null) throw Exception('Could not read the selected ZIP file.');
      await BackupService.instance.restoreBackup(bytes);
      await controller.reloadAfterBackupRestore();
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Improve data restored successfully.')));
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Restore failed: $e')));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Backup & Restore')),
    body: SafeArea(child: ListView(
    padding: const EdgeInsets.fromLTRB(20, 22, 20, 30),
    children: [
      const SectionHeader(title: 'Backup & Restore', subtitle: 'Keep a portable copy of your Improve data.'),
      GlassCard(child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.archive_outlined, size: 30),
          const SizedBox(height: 10),
          Text('Export a ZIP backup', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text('Creates a real .zip file containing your objectives, checkpoints, notes, planner, settings and profile image. It works offline.'),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => _export(context), icon: const Icon(Icons.download_rounded), label: const Text('Export ZIP backup'))),
        ]),
      )),
      const SizedBox(height: 14),
      GlassCard(child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.restore_rounded, size: 30),
          const SizedBox(height: 10),
          Text('Restore from ZIP', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text('Choose a previously exported Improve ZIP. Invalid or damaged archives are rejected before your current data is replaced.'),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: () => _restore(context), icon: const Icon(Icons.folder_open_rounded), label: const Text('Choose backup ZIP'))),
        ]),
      )),
      const SizedBox(height: 14),
      Text('Important: save the ZIP in Documents, Downloads or another location outside Improve. Android removes app-private data when the app is uninstalled.', style: Theme.of(context).textTheme.bodySmall),
    ],
  )),
  );
}
