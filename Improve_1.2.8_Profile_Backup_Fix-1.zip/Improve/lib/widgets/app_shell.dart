import 'package:flutter/material.dart';
import '../state/improve_controller.dart';
import '../screens/calendar_screen.dart';
import '../screens/home_screen.dart';
import '../screens/notes_screen.dart';
import '../screens/planner_screen.dart';
import '../screens/profile_screen.dart';
import '../services/backup_service.dart';
import 'package:file_picker/file_picker.dart';
import '../screens/statistics_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.controller});
  final ImproveController controller;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int selectedIndex = 0;
  bool _startupPromptsScheduled = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_startupPromptsScheduled) return;
    _startupPromptsScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) => _runStartupPrompts());
  }

  Future<void> _runStartupPrompts() async {
    if (!mounted) return;
    if (widget.controller.needsInitialRestorePrompt) {
      final choice = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          title: const Text('Welcome to Improve'),
          content: const Text('Do you have an Improve ZIP backup to restore? You can restore your previous data now or skip and start fresh.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Skip for now')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Choose backup ZIP')),
          ],
        ),
      );
      if (!mounted) return;
      var restorePromptHandled = choice == false;
      if (choice == true) {
        try {
          final result = await FilePicker.platform.pickFiles(
            dialogTitle: 'Choose Improve ZIP backup',
            type: FileType.custom,
            allowedExtensions: ['zip'],
            withData: true,
          );
          if (result != null && result.files.isNotEmpty) {
            final bytes = result.files.single.bytes;
            if (bytes == null) throw Exception('Could not read the selected ZIP file.');
            await BackupService.instance.restoreBackup(bytes);
            await widget.controller.reloadAfterBackupRestore();
            restorePromptHandled = true;
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Your Improve backup has been restored.')));
          }
        } catch (e) {
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Restore failed: $e')));
        }
      }
      if (restorePromptHandled) {
        await widget.controller.markInitialRestorePromptHandled();
      }
    }
    if (!mounted || !widget.controller.profilePromptDue) return;
    final setup = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Set up your profile'),
        content: const Text('Add a name and a few details to personalize Improve. This is optional and you can do it later.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Maybe later')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Set up profile')),
        ],
      ),
    );
    if (!mounted) return;
    if (setup == true) {
      // If the user opens the form but does not finish it, wait three more launches.
      await widget.controller.dismissProfilePrompt();
      if (!mounted) return;
      await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProfileScreen(controller: widget.controller, startEditing: true)));
    } else {
      await widget.controller.dismissProfilePrompt();
    }
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final screens = [
      HomeScreen(controller: widget.controller),
      CalendarScreen(controller: widget.controller),
      NotesScreen(controller: widget.controller),
      PlannerScreen(controller: widget.controller),
      StatisticsScreen(controller: widget.controller),
      ProfileScreen(controller: widget.controller),
    ];
    const destinations = [
      NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
      NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'Calendar'),
      NavigationDestination(icon: Icon(Icons.sticky_note_2_outlined), label: 'Notes'),
      NavigationDestination(icon: Icon(Icons.event_note_outlined), label: 'Planner'),
      NavigationDestination(icon: Icon(Icons.insights_outlined), label: 'Stats'),
      NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person_rounded), label: 'Profile'),
    ];

    return Container(
      // OLED: pure black. Light: soft gradient kept.
      decoration: BoxDecoration(
        color: dark ? const Color(0xFF000000) : null,
        gradient: dark
            ? null
            : const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFFF8F8FF), Color(0xFFEEF0FA), Color(0xFFE7E9F8)],
              ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(child: IndexedStack(index: selectedIndex, children: screens)),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedIndex,
          onDestinationSelected: (index) => setState(() => selectedIndex = index),
          destinations: destinations,
          height: 68,
          labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
        ),
      ),
    );
  }
}
